# SudanPay PWA Trading App

## Overview
A Progressive Web App (PWA) that transforms the existing SudanPay website into a mobile-optimized trading application with Binance-style UI/UX, featuring user accounts, internal wallet system, and admin controls. The application uses Arabic as the primary language with RTL layout support.

## Authentication
- Internet Identity integration for user authentication
- Automatic unique ID generation for each new user upon registration
- No manual registration process - users are created automatically on first login

## User Interface
- Dark theme design inspired by Binance trading app
- Mobile-first responsive design optimized for PWA installation
- Multi-page layout with distinct pages for navigation
- Bottom navigation bar for mobile (Binance-style) with main page switching
- Trading app aesthetic with modern UI components
- Arabic language interface with RTL layout consistency throughout the application
- Official SudanPay logo integration in header branding, login screen, and splash/loading screens

## Page Structure
The application consists of the following main pages accessible via bottom navigation:

### Home/Dashboard Page
- Account balance display
- Quick action buttons for deposit/withdraw
- Recent transaction summary
- Interactive charts showing balance trends

### Wallet Page
- Detailed wallet balance information
- Wallet management features
- Balance history and analytics

### Deposit Page
- Deposit request form with amount and details
- Commission fee calculation and display
- Deposit instructions and guidelines

### Withdraw Page
- Withdrawal request form with amount and destination
- Commission fee calculation and display
- Withdrawal processing information

### Transactions Page
- Complete transaction history (deposits, withdrawals)
- Transaction status tracking (pending, approved, rejected)
- Filtering and search capabilities

### Profile Page
- User account information and unique ID display
- Account settings and preferences
- Support and help information

## Wallet System
- Internal wallet system for each user with balance tracking
- One fixed admin wallet address that receives all commission fees
- Configurable commission rates for deposits and withdrawals
- Manual approval workflow for deposit and withdrawal requests
- No external bank API integration - all transactions are manually processed

## Transaction Management
- Deposit request submission with amount and details
- Withdrawal request submission with amount and destination
- Transaction status tracking (pending, approved, rejected)
- Commission fee calculation and display

## Admin Panel
- View all registered users and their unique IDs
- Monitor user balances and transaction history
- Approve or reject deposit/withdrawal requests
- Configure commission fee rates
- View total commission earnings
- Dashboard with charts for platform analytics

## Data Storage
The backend stores the following data in Motoko canister maps:
- User profiles with unique IDs and authentication details
- User wallet balances
- Transaction records (deposits, withdrawals, fees)
- Commission fee configurations
- Admin wallet information
- Transaction approval status

## Charts and Analytics
- Frontend chart libraries for interactive data visualization
- Balance history charts for users
- Transaction volume charts for admin
- Commission earnings tracking
- Platform usage analytics dashboard

## Progressive Web App Features
- PWA manifest for mobile installation with SudanPay branding
- Service worker for offline functionality
- App-like experience when installed on mobile devices
- Push notification capability for transaction updates
- Official logo integration in PWA manifest icons and app branding
