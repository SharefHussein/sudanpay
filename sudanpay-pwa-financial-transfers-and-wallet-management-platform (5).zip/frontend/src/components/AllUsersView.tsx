import { useGetAllUsers } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function AllUsersView() {
  const { data: users, isLoading } = useGetAllUsers();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">المستخدمون</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!users || users.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">المستخدمون</CardTitle>
          <CardDescription className="text-right">لا يوجد مستخدمون مسجلون</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Users className="h-5 w-5 text-chart-1" />
          المستخدمون ({users.length})
        </CardTitle>
        <CardDescription className="text-right">جميع المستخدمين المسجلين في المنصة</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">المستخدم</TableHead>
                <TableHead className="text-right">الاسم بالعربية</TableHead>
                <TableHead className="text-right">معلومات الاتصال</TableHead>
                <TableHead className="text-right">المعرف</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map(([principal, profile]) => {
                const initials = profile.arabicName?.slice(0, 2) || profile.name?.slice(0, 2) || 'مس';
                return (
                  <TableRow key={principal.toString()}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border-2 border-primary/20">
                          <AvatarFallback className="bg-gradient-to-br from-primary to-chart-1 text-primary-foreground">
                            {initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="text-right">
                          <div className="font-medium">{profile.name}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{profile.arabicName}</TableCell>
                    <TableCell className="text-right">{profile.contactInfo}</TableCell>
                    <TableCell className="text-right">
                      <code className="text-xs bg-accent/20 px-2 py-1 rounded">
                        {principal.toString().slice(0, 15)}...
                      </code>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
