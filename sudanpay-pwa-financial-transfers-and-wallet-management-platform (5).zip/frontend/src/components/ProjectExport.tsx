import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Download, Package, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ProjectExport() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  const handleGenerateZip = async () => {
    setIsGenerating(true);
    setDownloadUrl(null);

    try {
      // TODO: Call backend method when implemented
      // const result = await actor.generateProjectZip();
      // setDownloadUrl(result);
      
      // Temporary mock for UI demonstration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.error('وظيفة التصدير غير متوفرة حالياً - Backend functionality not yet implemented');
      
    } catch (error) {
      console.error('Error generating project ZIP:', error);
      toast.error('فشل في إنشاء ملف المشروع');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (downloadUrl) {
      window.open(downloadUrl, '_blank');
      toast.success('بدأ التنزيل');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          تصدير المشروع
        </CardTitle>
        <CardDescription className="text-right">
          تنزيل نسخة كاملة من كود المشروع (Frontend + Backend + Configuration)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-right">
            سيتم إنشاء ملف ZIP يحتوي على:
            <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
              <li>كود الواجهة الأمامية الكامل (React + TypeScript)</li>
              <li>كود الخادم الخلفي الكامل (Motoko)</li>
              <li>ملفات الإعدادات (package.json, dfx.json, etc.)</li>
              <li>سكريبتات البناء والنشر</li>
              <li>ملف README بالعربية والإنجليزية</li>
            </ul>
          </AlertDescription>
        </Alert>

        {downloadUrl && (
          <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-right text-green-800 dark:text-green-200">
              تم إنشاء ملف المشروع بنجاح! يمكنك الآن تنزيله.
            </AlertDescription>
          </Alert>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            onClick={handleGenerateZip}
            disabled={isGenerating}
            className="flex-1 h-12 bg-gradient-to-r from-primary to-chart-1"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-5 w-5 ml-2 animate-spin" />
                جاري إنشاء الملف...
              </>
            ) : (
              <>
                <Package className="h-5 w-5 ml-2" />
                إنشاء ملف ZIP
              </>
            )}
          </Button>

          {downloadUrl && (
            <Button
              onClick={handleDownload}
              variant="outline"
              className="flex-1 h-12 border-green-500 text-green-600 hover:bg-green-50"
            >
              <Download className="h-5 w-5 ml-2" />
              تنزيل المشروع
            </Button>
          )}
        </div>

        <div className="text-sm text-muted-foreground text-right space-y-2 pt-4 border-t">
          <p className="font-semibold">ملاحظات هامة:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>حجم الملف قد يكون كبيراً (عدة ميجابايت)</li>
            <li>التنزيل قد يستغرق بعض الوقت حسب سرعة الإنترنت</li>
            <li>الملف يحتوي على كود المصدر الكامل للمشروع</li>
            <li>يمكنك استخدام الكود لنشر نسخة خاصة من التطبيق</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
