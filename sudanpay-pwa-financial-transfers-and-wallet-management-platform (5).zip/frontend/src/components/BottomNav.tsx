import { useNavigate, useRouterState } from '@tanstack/react-router';
import { Home, Wallet, ArrowDownToLine, ArrowUpFromLine, History, User } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function BottomNav() {
  const navigate = useNavigate();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  const navItems = [
    { path: '/', icon: Home, label: 'الرئيسية' },
    { path: '/wallet', icon: Wallet, label: 'المحفظة' },
    { path: '/deposit', icon: ArrowDownToLine, label: 'إيداع' },
    { path: '/withdraw', icon: ArrowUpFromLine, label: 'سحب' },
    { path: '/transactions', icon: History, label: 'المعاملات' },
    { path: '/profile', icon: User, label: 'الحساب' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur border-t border-border/40 supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto px-2">
        <div className="grid grid-cols-6 gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.path;
            
            return (
              <button
                key={item.path}
                onClick={() => navigate({ to: item.path })}
                className={cn(
                  'flex flex-col items-center justify-center py-2 px-1 transition-colors',
                  isActive
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className={cn('h-5 w-5 mb-1', isActive && 'scale-110')} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
