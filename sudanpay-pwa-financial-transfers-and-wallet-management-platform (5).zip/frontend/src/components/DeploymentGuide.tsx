import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Code, Terminal, Globe, Server, Package, CheckCircle2, AlertCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function DeploymentGuide() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Globe className="h-5 w-5 text-primary" />
          دليل النشر والتوزيع
        </CardTitle>
        <CardDescription className="text-right">
          إرشادات كاملة لنشر التطبيق على الإنتاج
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" dir="rtl">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="frontend">Frontend</TabsTrigger>
            <TabsTrigger value="backend">Backend</TabsTrigger>
            <TabsTrigger value="production">الإنتاج</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <ScrollArea className="h-[500px] w-full rounded-md border p-4">
              <div className="space-y-6 text-right">
                <div>
                  <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    محتويات الحزمة
                  </h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>كود Frontend الكامل (React + TypeScript + Tailwind CSS)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>كود Backend الكامل (Motoko Canisters)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>ملفات الإعدادات (package.json, dfx.json, tsconfig.json, vite.config.js)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>سكريبتات البناء والنشر</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>ملف README شامل بالعربية والإنجليزية</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>ملفات PWA (manifest.json, service worker)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>ملفات SEO (sitemap.xml, robots.txt)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>مكونات UI الجاهزة (Shadcn/ui)</span>
                    </li>
                  </ul>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-bold mb-3">المتطلبات التقنية</h3>
                  <div className="space-y-3 text-sm">
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">Node.js</p>
                      <p className="text-muted-foreground">الإصدار 18.0.0 أو أحدث</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">DFX (Internet Computer SDK)</p>
                      <p className="text-muted-foreground">الإصدار 0.15.0 أو أحدث</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">pnpm أو npm</p>
                      <p className="text-muted-foreground">أحدث إصدار مستقر</p>
                    </div>
                  </div>
                </div>

                <Separator />

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-right">
                    <strong>ملاحظة هامة:</strong> تأكد من قراءة ملف README.md الكامل قبل البدء في عملية النشر.
                    يحتوي على تعليمات مفصلة وحلول للمشاكل الشائعة.
                  </AlertDescription>
                </Alert>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="frontend" className="space-y-4">
            <ScrollArea className="h-[500px] w-full rounded-md border p-4">
              <div className="space-y-6 text-right">
                <div>
                  <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <Code className="h-5 w-5 text-primary" />
                    بناء Frontend
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold mb-2">1. تثبيت التبعيات</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        cd frontend<br />
                        pnpm install<br />
                        # أو<br />
                        npm install
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">2. إعداد متغيرات البيئة</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        # إنشاء ملف .env<br />
                        VITE_CANISTER_ID_BACKEND=&lt;backend-canister-id&gt;<br />
                        VITE_DFX_NETWORK=local<br />
                        VITE_HOST=http://localhost:4943
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">3. البناء للإنتاج</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        pnpm build<br />
                        # أو<br />
                        npm run build
                      </div>
                      <p className="text-sm text-muted-foreground mt-2">
                        الملفات المبنية ستكون في مجلد: frontend/dist/
                      </p>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">4. اختبار البناء محلياً</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        pnpm preview<br />
                        # أو<br />
                        npm run preview
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-bold mb-3">خيارات النشر</h3>
                  <div className="space-y-3 text-sm">
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">Vercel</p>
                      <p className="text-muted-foreground">نشر سريع مع CI/CD تلقائي</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">Netlify</p>
                      <p className="text-muted-foreground">استضافة مجانية مع SSL</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="font-semibold mb-1">Internet Computer</p>
                      <p className="text-muted-foreground">استضافة لامركزية كاملة</p>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="backend" className="space-y-4">
            <ScrollArea className="h-[500px] w-full rounded-md border p-4">
              <div className="space-y-6 text-right">
                <div>
                  <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <Server className="h-5 w-5 text-primary" />
                    نشر Backend
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold mb-2">1. تشغيل شبكة محلية</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        dfx start --clean --background
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">2. إنشاء الهويات</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        dfx identity new admin<br />
                        dfx identity use admin
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">3. نشر Canisters محلياً</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        dfx deploy
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">4. النشر على الشبكة الرئيسية</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        # إضافة Cycles<br />
                        dfx wallet balance<br />
                        <br />
                        # النشر<br />
                        dfx deploy --network ic
                      </div>
                    </div>

                    <div>
                      <p className="font-semibold mb-2">5. الحصول على Canister IDs</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm" dir="ltr">
                        dfx canister id backend --network ic
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-right">
                    <strong>تنبيه:</strong> تأكد من وجود Cycles كافية في محفظتك قبل النشر على الشبكة الرئيسية.
                    يمكنك الحصول على Cycles من خلال ICP tokens.
                  </AlertDescription>
                </Alert>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="production" className="space-y-4">
            <ScrollArea className="h-[500px] w-full rounded-md border p-4">
              <div className="space-y-6 text-right">
                <div>
                  <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <Terminal className="h-5 w-5 text-primary" />
                    النشر الكامل للإنتاج
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold mb-2">خطوات النشر الكامل</p>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>نشر Backend على Internet Computer</li>
                        <li>الحصول على Canister IDs</li>
                        <li>تحديث متغيرات البيئة في Frontend</li>
                        <li>بناء Frontend للإنتاج</li>
                        <li>نشر Frontend على الخدمة المختارة</li>
                        <li>تحديث DNS وإعدادات SSL</li>
                        <li>اختبار التطبيق الكامل</li>
                      </ol>
                    </div>

                    <Separator />

                    <div>
                      <p className="font-semibold mb-2">قائمة التحقق النهائية</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>جميع متغيرات البيئة محدثة</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>Backend منشور ويعمل بشكل صحيح</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>Frontend مبني ومحسّن</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>SSL/TLS مفعّل</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>PWA Manifest محدث</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>SEO Meta Tags محدثة</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                          <span>اختبار شامل للتطبيق</span>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <p className="font-semibold mb-2">مراقبة الأداء</p>
                      <div className="space-y-2 text-sm">
                        <p>بعد النشر، راقب:</p>
                        <ul className="list-disc list-inside space-y-1 mr-4">
                          <li>استهلاك Cycles</li>
                          <li>أوقات الاستجابة</li>
                          <li>معدلات الخطأ</li>
                          <li>استخدام الذاكرة</li>
                          <li>عدد المستخدمين النشطين</li>
                        </ul>
                      </div>
                    </div>

                    <Separator />

                    <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-right text-green-800 dark:text-green-200">
                        <strong>نجح النشر!</strong> تطبيقك الآن جاهز للاستخدام في بيئة الإنتاج.
                        تأكد من مراقبة الأداء والأمان بشكل مستمر.
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
