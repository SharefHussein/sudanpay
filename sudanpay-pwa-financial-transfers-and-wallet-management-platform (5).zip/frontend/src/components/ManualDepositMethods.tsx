import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useSubmitManualDepositRequest, useGetCommissionConfig } from '../hooks/useQueries';
import { toast } from 'sonner';
import { Building2, Coins, ArrowDownToLine, Info } from 'lucide-react';
import { DepositMethod, DepositNetwork } from '../backend';

export default function ManualDepositMethods() {
  const submitManualDeposit = useSubmitManualDepositRequest();
  const { data: commissionConfig } = useGetCommissionConfig();

  // Bank Transfer State
  const [bankAmount, setBankAmount] = useState('');
  const [bankProof, setBankProof] = useState('');

  // USDT State
  const [usdtAmount, setUsdtAmount] = useState('');
  const [usdtNetwork, setUsdtNetwork] = useState<DepositNetwork | ''>('');
  const [usdtTxid, setUsdtTxid] = useState('');

  const calculateCommission = (amount: number) => {
    if (!commissionConfig) return 0;
    return amount * commissionConfig.depositFee;
  };

  const calculateNetAmount = (amount: number) => {
    return amount - calculateCommission(amount);
  };

  const handleBankSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(bankAmount);

    if (isNaN(amount) || amount <= 0) {
      toast.error('الرجاء إدخال مبلغ صحيح');
      return;
    }

    if (!bankProof.trim()) {
      toast.error('الرجاء إدخال إثبات التحويل أو ملاحظات');
      return;
    }

    try {
      await submitManualDeposit.mutateAsync({
        method: DepositMethod.bank,
        network: null,
        amount,
        proof: bankProof,
        txid: null,
        instructions: 'طلب إيداع عبر التحويل البنكي',
      });

      toast.success('تم إرسال طلب الإيداع بنجاح، في انتظار المراجعة');
      setBankAmount('');
      setBankProof('');
    } catch (error) {
      toast.error('فشل إرسال طلب الإيداع');
      console.error(error);
    }
  };

  const handleUsdtSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(usdtAmount);

    if (isNaN(amount) || amount <= 0) {
      toast.error('الرجاء إدخال مبلغ صحيح');
      return;
    }

    if (!usdtNetwork) {
      toast.error('الرجاء اختيار الشبكة');
      return;
    }

    if (!usdtTxid.trim()) {
      toast.error('الرجاء إدخال معرف المعاملة (TXID)');
      return;
    }

    try {
      await submitManualDeposit.mutateAsync({
        method: DepositMethod.usdt,
        network: usdtNetwork as DepositNetwork,
        amount,
        proof: null,
        txid: usdtTxid,
        instructions: `طلب إيداع USDT عبر شبكة ${usdtNetwork}`,
      });

      toast.success('تم إرسال طلب الإيداع بنجاح، في انتظار المراجعة');
      setUsdtAmount('');
      setUsdtNetwork('');
      setUsdtTxid('');
    } catch (error) {
      toast.error('فشل إرسال طلب الإيداع');
      console.error(error);
    }
  };

  return (
    <Card className="border-chart-1/30 shadow-lg">
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2 text-2xl">
          <ArrowDownToLine className="h-6 w-6 text-chart-1" />
          طرق الإيداع اليدوية
        </CardTitle>
        <CardDescription className="text-right text-base">
          اختر طريقة الإيداع المناسبة لك
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="bank" className="w-full" dir="rtl">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="bank" className="gap-2">
              <Building2 className="h-4 w-4" />
              تحويل بنكي (يدوي)
            </TabsTrigger>
            <TabsTrigger value="usdt" className="gap-2">
              <Coins className="h-4 w-4" />
              USDT (يدوي)
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bank" className="space-y-4">
            <div className="bg-chart-1/10 border border-chart-1/30 rounded-lg p-4 text-right space-y-2">
              <div className="flex items-start gap-2">
                <Info className="h-5 w-5 text-chart-1 mt-0.5 flex-shrink-0" />
                <div className="space-y-1 text-sm">
                  <p className="font-semibold text-chart-1">معلومات الحساب البنكي:</p>
                  <p>اسم البنك: بنك السودان المركزي</p>
                  <p>رقم الحساب: 1234567890</p>
                  <p>اسم صاحب الحساب: SudanPay</p>
                  <p className="text-muted-foreground mt-2">
                    قم بتحويل المبلغ إلى الحساب أعلاه، ثم أدخل المبلغ وإثبات التحويل أدناه
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleBankSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bankAmount" className="text-right block text-base">
                  المبلغ (SDG)
                </Label>
                <Input
                  id="bankAmount"
                  type="number"
                  step="0.01"
                  placeholder="أدخل المبلغ"
                  value={bankAmount}
                  onChange={(e) => setBankAmount(e.target.value)}
                  className="text-right text-lg h-12"
                  dir="rtl"
                />
              </div>

              {bankAmount && parseFloat(bankAmount) > 0 && commissionConfig && (
                <div className="bg-accent/10 p-4 rounded-lg space-y-2 text-right">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">المبلغ المطلوب:</span>
                    <span className="font-medium">{parseFloat(bankAmount).toFixed(2)} SDG</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">رسوم العمولة ({(commissionConfig.depositFee * 100).toFixed(1)}%):</span>
                    <span className="font-medium text-chart-3">
                      {calculateCommission(parseFloat(bankAmount)).toFixed(2)} SDG
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-bold pt-2 border-t">
                    <span>المبلغ الصافي:</span>
                    <span className="text-chart-1">
                      {calculateNetAmount(parseFloat(bankAmount)).toFixed(2)} SDG
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="bankProof" className="text-right block text-base">
                  إثبات التحويل / ملاحظات
                </Label>
                <Textarea
                  id="bankProof"
                  placeholder="أدخل رقم الإيصال أو تفاصيل التحويل أو أي ملاحظات"
                  value={bankProof}
                  onChange={(e) => setBankProof(e.target.value)}
                  className="text-right min-h-24"
                  dir="rtl"
                />
              </div>

              <Button
                type="submit"
                disabled={submitManualDeposit.isPending}
                className="w-full bg-chart-1 hover:bg-chart-1/90 h-12 text-base font-semibold shadow-lg hover:shadow-chart-1/50 transition-all"
              >
                {submitManualDeposit.isPending ? 'جاري الإرسال...' : 'إرسال طلب الإيداع'}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="usdt" className="space-y-4">
            <div className="bg-chart-3/10 border border-chart-3/30 rounded-lg p-4 text-right space-y-2">
              <div className="flex items-start gap-2">
                <Info className="h-5 w-5 text-chart-3 mt-0.5 flex-shrink-0" />
                <div className="space-y-1 text-sm">
                  <p className="font-semibold text-chart-3">عنوان محفظة USDT:</p>
                  <p className="font-mono text-xs break-all bg-background/50 p-2 rounded">
                    TXhZrb4HcW2KKqXvXqNqN3qVqXqNqN3qVq
                  </p>
                  <p className="text-muted-foreground mt-2">
                    قم بإرسال USDT إلى العنوان أعلاه، ثم أدخل المبلغ والشبكة ومعرف المعاملة (TXID) أدناه
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleUsdtSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="usdtNetwork" className="text-right block text-base">
                  الشبكة
                </Label>
                <Select value={usdtNetwork} onValueChange={(value) => setUsdtNetwork(value as DepositNetwork)}>
                  <SelectTrigger id="usdtNetwork" className="text-right h-12">
                    <SelectValue placeholder="اختر الشبكة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={DepositNetwork.TRC20}>TRC20 (Tron)</SelectItem>
                    <SelectItem value={DepositNetwork.ERC20}>ERC20 (Ethereum)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="usdtAmount" className="text-right block text-base">
                  المبلغ (USDT)
                </Label>
                <Input
                  id="usdtAmount"
                  type="number"
                  step="0.01"
                  placeholder="أدخل المبلغ"
                  value={usdtAmount}
                  onChange={(e) => setUsdtAmount(e.target.value)}
                  className="text-right text-lg h-12"
                  dir="rtl"
                />
              </div>

              {usdtAmount && parseFloat(usdtAmount) > 0 && commissionConfig && (
                <div className="bg-accent/10 p-4 rounded-lg space-y-2 text-right">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">المبلغ المطلوب:</span>
                    <span className="font-medium">{parseFloat(usdtAmount).toFixed(2)} USDT</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">رسوم العمولة ({(commissionConfig.depositFee * 100).toFixed(1)}%):</span>
                    <span className="font-medium text-chart-3">
                      {calculateCommission(parseFloat(usdtAmount)).toFixed(2)} USDT
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-bold pt-2 border-t">
                    <span>المبلغ الصافي:</span>
                    <span className="text-chart-1">
                      {calculateNetAmount(parseFloat(usdtAmount)).toFixed(2)} USDT
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="usdtTxid" className="text-right block text-base">
                  معرف المعاملة (TXID)
                </Label>
                <Input
                  id="usdtTxid"
                  type="text"
                  placeholder="أدخل معرف المعاملة"
                  value={usdtTxid}
                  onChange={(e) => setUsdtTxid(e.target.value)}
                  className="text-right h-12 font-mono text-sm"
                  dir="ltr"
                />
              </div>

              <Button
                type="submit"
                disabled={submitManualDeposit.isPending}
                className="w-full bg-chart-3 hover:bg-chart-3/90 h-12 text-base font-semibold shadow-lg hover:shadow-chart-3/50 transition-all"
              >
                {submitManualDeposit.isPending ? 'جاري الإرسال...' : 'إرسال طلب الإيداع'}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
