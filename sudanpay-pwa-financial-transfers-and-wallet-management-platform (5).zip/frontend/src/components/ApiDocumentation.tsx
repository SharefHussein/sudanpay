import { useGetApiEndpoints } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Code, Shield, User } from 'lucide-react';
import { UserRole } from '../backend';

export default function ApiDocumentation() {
  const { data: endpoints, isLoading } = useGetApiEndpoints();

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case UserRole.admin:
        return (
          <Badge variant="destructive" className="gap-1">
            <Shield className="h-3 w-3" />
            مسؤول
          </Badge>
        );
      case UserRole.user:
        return (
          <Badge variant="default" className="gap-1">
            <User className="h-3 w-3" />
            مستخدم
          </Badge>
        );
      default:
        return <Badge variant="secondary">ضيف</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">توثيق API</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Code className="h-5 w-5 text-primary" />
          توثيق API العام
        </CardTitle>
        <CardDescription className="text-right">
          قائمة بجميع نقاط النهاية المتاحة في API مع الأدوار المطلوبة للوصول
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {endpoints && endpoints.length > 0 ? (
            endpoints.map((endpoint, index) => (
              <div
                key={index}
                className="p-4 rounded-lg border border-border bg-card/50 hover:bg-card transition-colors"
              >
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1 text-right">
                    <code className="text-sm font-mono bg-muted px-2 py-1 rounded text-primary">
                      {endpoint.name}
                    </code>
                  </div>
                  {getRoleBadge(endpoint.accessRole)}
                </div>
                <p className="text-sm text-muted-foreground text-right leading-relaxed">
                  {endpoint.description}
                </p>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Code className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>لا توجد نقاط نهاية متاحة</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
