import { useGetCallerWalletBalance } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, TrendingUp, ArrowUpRight } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function WalletOverview() {
  const { data: balance, isLoading } = useGetCallerWalletBalance();

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card className="col-span-full md:col-span-2 border-primary/20 bg-gradient-to-br from-card via-card to-primary/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">الرصيد الإجمالي</CardTitle>
          <div className="bg-primary/10 p-2 rounded-lg">
            <Wallet className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-12 w-48" />
          ) : (
            <div className="space-y-1">
              <div className="text-4xl font-bold tracking-tight">
                {balance?.toFixed(2)} <span className="text-2xl text-muted-foreground">SDG</span>
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-chart-1" />
                متاح للسحب
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">حالة الحساب</CardTitle>
          <ArrowUpRight className="h-4 w-4 text-chart-1" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-chart-1">نشط</div>
          <p className="text-xs text-muted-foreground mt-1">جميع الخدمات متاحة</p>
        </CardContent>
      </Card>
    </div>
  );
}
