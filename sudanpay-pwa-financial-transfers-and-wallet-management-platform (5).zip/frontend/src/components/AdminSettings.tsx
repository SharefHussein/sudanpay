import { useState, useEffect } from 'react';
import { useGetCommissionConfig, useUpdateCommissionConfig, useGetPublicSiteUrl, useUpdatePublicSiteUrl } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Settings, Save, Copy, Link, Check } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';

export default function AdminSettings() {
  const { data: config, isLoading: configLoading } = useGetCommissionConfig();
  const { data: siteUrl, isLoading: urlLoading } = useGetPublicSiteUrl();
  const updateConfig = useUpdateCommissionConfig();
  const updateUrl = useUpdatePublicSiteUrl();
  
  const [depositFee, setDepositFee] = useState('');
  const [withdrawalFee, setWithdrawalFee] = useState('');
  const [publicUrl, setPublicUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (config) {
      setDepositFee((config.depositFee * 100).toFixed(2));
      setWithdrawalFee((config.withdrawalFee * 100).toFixed(2));
    }
  }, [config]);

  useEffect(() => {
    if (siteUrl) {
      setPublicUrl(siteUrl.url);
    }
  }, [siteUrl]);

  const handleCommissionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const depositFeeNum = parseFloat(depositFee) / 100;
    const withdrawalFeeNum = parseFloat(withdrawalFee) / 100;

    if (isNaN(depositFeeNum) || isNaN(withdrawalFeeNum)) {
      toast.error('يرجى إدخال قيم صحيحة');
      return;
    }

    if (depositFeeNum < 0 || depositFeeNum > 1 || withdrawalFeeNum < 0 || withdrawalFeeNum > 1) {
      toast.error('يجب أن تكون النسبة بين 0% و 100%');
      return;
    }

    try {
      await updateConfig.mutateAsync({ 
        depositFee: depositFeeNum, 
        withdrawalFee: withdrawalFeeNum,
        transferFee: config?.transferFee || 0.01
      });
      toast.success('تم تحديث إعدادات العمولة بنجاح');
    } catch (error) {
      toast.error('فشل تحديث إعدادات العمولة');
      console.error(error);
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!publicUrl.trim()) {
      toast.error('يرجى إدخال رابط صحيح');
      return;
    }

    try {
      await updateUrl.mutateAsync(publicUrl);
      toast.success('تم تحديث رابط الموقع بنجاح');
    } catch (error) {
      toast.error('فشل تحديث رابط الموقع');
      console.error(error);
    }
  };

  const handleCopyUrl = async () => {
    if (siteUrl?.url) {
      try {
        await navigator.clipboard.writeText(siteUrl.url);
        setCopied(true);
        toast.success('تم نسخ الرابط');
        setTimeout(() => setCopied(false), 2000);
      } catch (error) {
        toast.error('فشل نسخ الرابط');
      }
    }
  };

  if (configLoading || urlLoading) {
    return (
      <div className="space-y-6 max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-right">الإعدادات</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      {/* Commission Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-right flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            إعدادات العمولة
          </CardTitle>
          <CardDescription className="text-right">
            تحديد نسب العمولة على الإيداعات والسحوبات
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCommissionSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="depositFee" className="text-right block">عمولة الإيداع (%)</Label>
              <Input
                id="depositFee"
                type="number"
                step="0.01"
                value={depositFee}
                onChange={(e) => setDepositFee(e.target.value)}
                placeholder="2.00"
                className="text-right text-lg"
                dir="rtl"
              />
              <p className="text-sm text-muted-foreground text-right">
                النسبة الحالية: {config ? (config.depositFee * 100).toFixed(2) : '0'}%
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="withdrawalFee" className="text-right block">عمولة السحب (%)</Label>
              <Input
                id="withdrawalFee"
                type="number"
                step="0.01"
                value={withdrawalFee}
                onChange={(e) => setWithdrawalFee(e.target.value)}
                placeholder="3.00"
                className="text-right text-lg"
                dir="rtl"
              />
              <p className="text-sm text-muted-foreground text-right">
                النسبة الحالية: {config ? (config.withdrawalFee * 100).toFixed(2) : '0'}%
              </p>
            </div>

            <Button
              type="submit"
              className="w-full h-11 bg-gradient-to-r from-primary to-chart-1"
              disabled={updateConfig.isPending}
            >
              {updateConfig.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 ml-2" />
                  حفظ التغييرات
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Separator />

      {/* Public Site URL */}
      <Card>
        <CardHeader>
          <CardTitle className="text-right flex items-center gap-2">
            <Link className="h-5 w-5 text-primary" />
            رابط الموقع العام
          </CardTitle>
          <CardDescription className="text-right">
            عرض وتحديث رابط الموقع العام للتطبيق
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Display Current URL */}
          <div className="space-y-2">
            <Label className="text-right block">الرابط الحالي</Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleCopyUrl}
                className="shrink-0"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
              <div className="flex-1 p-3 rounded-lg bg-muted text-sm font-mono break-all text-right">
                {siteUrl?.url || 'لم يتم تعيين رابط'}
              </div>
            </div>
          </div>

          {/* Update URL Form */}
          <form onSubmit={handleUrlSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="publicUrl" className="text-right block">تحديث الرابط</Label>
              <Input
                id="publicUrl"
                type="url"
                value={publicUrl}
                onChange={(e) => setPublicUrl(e.target.value)}
                placeholder="https://sudanpay.app"
                className="text-right text-lg"
                dir="rtl"
              />
            </div>

            <Button
              type="submit"
              className="w-full h-11 bg-gradient-to-r from-primary to-chart-2"
              disabled={updateUrl.isPending}
            >
              {updateUrl.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                  جاري التحديث...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 ml-2" />
                  تحديث الرابط
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
