import { useState } from 'react';
import { useGetCallerWalletLinks, useAddWalletLink, useRemoveWalletLink } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Wallet, Trash2, Link as LinkIcon, Mail, CreditCard, Loader2, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import type { WalletLinkType } from '../backend';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export default function WalletLinking() {
  const { data: walletLinks, isLoading } = useGetCallerWalletLinks();
  const addWalletLink = useAddWalletLink();
  const removeWalletLink = useRemoveWalletLink();

  const [trustWalletAddress, setTrustWalletAddress] = useState('');
  const [perfectMoneyAccount, setPerfectMoneyAccount] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');

  const validateWalletAddress = (address: string): boolean => {
    // Basic validation for wallet address (alphanumeric, 20-50 chars)
    return /^[a-zA-Z0-9]{20,50}$/.test(address);
  };

  const validateAccountNumber = (account: string): boolean => {
    // Basic validation for Perfect Money account (U followed by digits)
    return /^U\d{7,10}$/.test(account);
  };

  const validateEmail = (email: string): boolean => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleAddTrustWallet = async () => {
    if (!trustWalletAddress.trim()) {
      toast.error('يرجى إدخال عنوان المحفظة');
      return;
    }

    if (!validateWalletAddress(trustWalletAddress)) {
      toast.error('عنوان المحفظة غير صحيح (20-50 حرف وأرقام)');
      return;
    }

    try {
      const linkType: WalletLinkType = {
        __kind__: 'trustWallet',
        trustWallet: trustWalletAddress,
      };
      await addWalletLink.mutateAsync(linkType);
      toast.success('تم ربط Trust Wallet بنجاح');
      setTrustWalletAddress('');
    } catch (error) {
      console.error('Error adding Trust Wallet:', error);
      toast.error('فشل ربط المحفظة');
    }
  };

  const handleAddPerfectMoney = async () => {
    if (!perfectMoneyAccount.trim()) {
      toast.error('يرجى إدخال رقم الحساب');
      return;
    }

    if (!validateAccountNumber(perfectMoneyAccount)) {
      toast.error('رقم الحساب غير صحيح (يجب أن يبدأ بـ U متبوعاً بأرقام)');
      return;
    }

    try {
      const linkType: WalletLinkType = {
        __kind__: 'perfectMoney',
        perfectMoney: perfectMoneyAccount,
      };
      await addWalletLink.mutateAsync(linkType);
      toast.success('تم ربط Perfect Money بنجاح');
      setPerfectMoneyAccount('');
    } catch (error) {
      console.error('Error adding Perfect Money:', error);
      toast.error('فشل ربط الحساب');
    }
  };

  const handleAddPayPal = async () => {
    if (!paypalEmail.trim()) {
      toast.error('يرجى إدخال البريد الإلكتروني');
      return;
    }

    if (!validateEmail(paypalEmail)) {
      toast.error('البريد الإلكتروني غير صحيح');
      return;
    }

    try {
      const linkType: WalletLinkType = {
        __kind__: 'paypal',
        paypal: paypalEmail,
      };
      await addWalletLink.mutateAsync(linkType);
      toast.success('تم ربط PayPal بنجاح');
      setPaypalEmail('');
    } catch (error) {
      console.error('Error adding PayPal:', error);
      toast.error('فشل ربط الحساب');
    }
  };

  const handleRemoveLink = async (index: number) => {
    try {
      await removeWalletLink.mutateAsync(BigInt(index));
      toast.success('تم إلغاء الربط بنجاح');
    } catch (error) {
      console.error('Error removing wallet link:', error);
      toast.error('فشل إلغاء الربط');
    }
  };

  const getWalletLinkDisplay = (link: any) => {
    if (link.linkType.__kind__ === 'trustWallet') {
      return {
        type: 'Trust Wallet',
        value: link.linkType.trustWallet,
        icon: <Wallet className="h-5 w-5 text-chart-1" />,
        color: 'chart-1',
      };
    } else if (link.linkType.__kind__ === 'perfectMoney') {
      return {
        type: 'Perfect Money',
        value: link.linkType.perfectMoney,
        icon: <CreditCard className="h-5 w-5 text-chart-2" />,
        color: 'chart-2',
      };
    } else if (link.linkType.__kind__ === 'paypal') {
      return {
        type: 'PayPal',
        value: link.linkType.paypal,
        icon: <Mail className="h-5 w-5 text-chart-3" />,
        color: 'chart-3',
      };
    }
    return null;
  };

  return (
    <Card className="border-primary/30 bg-gradient-to-br from-card to-primary/5 shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/15 p-3 rounded-xl shadow-sm">
            <LinkIcon className="h-6 w-6 text-primary" />
          </div>
          <div className="text-right flex-1">
            <CardTitle className="text-xl font-bold">ربط المحافظ الخارجية</CardTitle>
            <CardDescription className="text-base">اربط حساباتك المصرفية الإلكترونية</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Linked Wallets Display */}
        {walletLinks && walletLinks.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-muted-foreground text-right">المحافظ المربوطة</h3>
            <div className="space-y-2">
              {walletLinks.map((link, index) => {
                const display = getWalletLinkDisplay(link);
                if (!display) return null;

                return (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-4 rounded-xl border border-${display.color}/30 bg-${display.color}/5 hover:bg-${display.color}/10 transition-all duration-300`}
                  >
                    <div className="flex items-center gap-3 flex-1" dir="rtl">
                      <div className={`bg-${display.color}/15 p-2.5 rounded-lg`}>
                        {display.icon}
                      </div>
                      <div className="text-right flex-1">
                        <p className="font-bold text-sm mb-0.5">{display.type}</p>
                        <p className="text-xs text-muted-foreground font-mono break-all">{display.value}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveLink(index)}
                      disabled={removeWalletLink.isPending}
                      className="shrink-0 hover:bg-destructive/20 hover:text-destructive"
                    >
                      {removeWalletLink.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                );
              })}
            </div>
            <Separator className="bg-border/50" />
          </div>
        )}

        {/* Add New Wallet Links */}
        <Tabs defaultValue="trustwallet" dir="rtl" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="trustwallet" className="text-sm font-bold">Trust Wallet</TabsTrigger>
            <TabsTrigger value="perfectmoney" className="text-sm font-bold">Perfect Money</TabsTrigger>
            <TabsTrigger value="paypal" className="text-sm font-bold">PayPal</TabsTrigger>
          </TabsList>

          <TabsContent value="trustwallet" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="trustwallet-address" className="text-right block font-medium">
                عنوان المحفظة
              </Label>
              <Input
                id="trustwallet-address"
                value={trustWalletAddress}
                onChange={(e) => setTrustWalletAddress(e.target.value)}
                placeholder="أدخل عنوان Trust Wallet"
                className="text-right h-12"
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground text-right">
                عنوان المحفظة يجب أن يكون 20-50 حرف وأرقام
              </p>
            </div>
            <Button
              onClick={handleAddTrustWallet}
              disabled={addWalletLink.isPending}
              className="w-full h-12 bg-gradient-to-r from-chart-1 to-chart-1/80 hover:from-chart-1/90 hover:to-chart-1/70 shadow-md"
            >
              {addWalletLink.isPending ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  جاري الربط...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-5 w-5 mr-2" />
                  ربط Trust Wallet
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="perfectmoney" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="perfectmoney-account" className="text-right block font-medium">
                رقم الحساب
              </Label>
              <Input
                id="perfectmoney-account"
                value={perfectMoneyAccount}
                onChange={(e) => setPerfectMoneyAccount(e.target.value)}
                placeholder="U1234567"
                className="text-right h-12"
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground text-right">
                رقم الحساب يجب أن يبدأ بـ U متبوعاً بأرقام
              </p>
            </div>
            <Button
              onClick={handleAddPerfectMoney}
              disabled={addWalletLink.isPending}
              className="w-full h-12 bg-gradient-to-r from-chart-2 to-chart-2/80 hover:from-chart-2/90 hover:to-chart-2/70 shadow-md"
            >
              {addWalletLink.isPending ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  جاري الربط...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-5 w-5 mr-2" />
                  ربط Perfect Money
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="paypal" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="paypal-email" className="text-right block font-medium">
                البريد الإلكتروني
              </Label>
              <Input
                id="paypal-email"
                type="email"
                value={paypalEmail}
                onChange={(e) => setPaypalEmail(e.target.value)}
                placeholder="example@email.com"
                className="text-right h-12"
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground text-right">
                البريد الإلكتروني المرتبط بحساب PayPal
              </p>
            </div>
            <Button
              onClick={handleAddPayPal}
              disabled={addWalletLink.isPending}
              className="w-full h-12 bg-gradient-to-r from-chart-3 to-chart-3/80 hover:from-chart-3/90 hover:to-chart-3/70 shadow-md"
            >
              {addWalletLink.isPending ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  جاري الربط...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-5 w-5 mr-2" />
                  ربط PayPal
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
