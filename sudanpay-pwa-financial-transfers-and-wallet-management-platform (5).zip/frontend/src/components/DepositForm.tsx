import { useState } from 'react';
import { useSubmitDepositRequest } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { ArrowDownToLine, Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function DepositForm() {
  const [amount, setAmount] = useState('');
  const [details, setDetails] = useState('');
  const submitDeposit = useSubmitDepositRequest();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast.error('يرجى إدخال مبلغ صحيح');
      return;
    }

    if (!details.trim()) {
      toast.error('يرجى إدخال تفاصيل الإيداع');
      return;
    }

    try {
      await submitDeposit.mutateAsync({ amount: amountNum, details });
      toast.success('تم إرسال طلب الإيداع بنجاح');
      setAmount('');
      setDetails('');
    } catch (error) {
      toast.error('فشل إرسال طلب الإيداع');
      console.error(error);
    }
  };

  const commission = parseFloat(amount) * 0.02 || 0;
  const netAmount = parseFloat(amount) - commission || 0;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <ArrowDownToLine className="h-5 w-5 text-chart-1" />
          طلب إيداع
        </CardTitle>
        <CardDescription className="text-right">
          أدخل المبلغ وتفاصيل الإيداع. سيتم مراجعة طلبك من قبل الإدارة.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Alert className="mb-6 border-chart-3/50 bg-chart-3/5">
          <Info className="h-4 w-4 text-chart-3" />
          <AlertDescription className="text-right text-sm">
            رسوم الإيداع: 2% من المبلغ المودع
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-right block">المبلغ (SDG)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="text-right text-lg"
              dir="rtl"
            />
          </div>

          {amount && parseFloat(amount) > 0 && (
            <div className="bg-accent/10 p-4 rounded-lg space-y-2 text-right">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">المبلغ المطلوب:</span>
                <span className="font-medium">{parseFloat(amount).toFixed(2)} SDG</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">رسوم الإيداع (2%):</span>
                <span className="font-medium text-destructive">-{commission.toFixed(2)} SDG</span>
              </div>
              <div className="border-t border-border pt-2 flex justify-between">
                <span className="font-semibold">المبلغ الصافي:</span>
                <span className="font-bold text-chart-1">{netAmount.toFixed(2)} SDG</span>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="details" className="text-right block">تفاصيل الإيداع</Label>
            <Textarea
              id="details"
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="أدخل تفاصيل الإيداع (رقم الحوالة، البنك، إلخ)"
              className="text-right min-h-[120px]"
              dir="rtl"
            />
          </div>

          <Button
            type="submit"
            className="w-full h-11 bg-gradient-to-r from-chart-1 to-chart-2"
            disabled={submitDeposit.isPending}
          >
            {submitDeposit.isPending ? (
              <>
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                جاري الإرسال...
              </>
            ) : (
              'إرسال طلب الإيداع'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
