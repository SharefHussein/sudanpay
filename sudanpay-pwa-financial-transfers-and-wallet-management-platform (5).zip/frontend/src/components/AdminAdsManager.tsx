import { useGetAllAds, useCreateAd, useUpdateAd, useDeleteAd, useSetAdActiveStatus } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Edit, Trash2, Eye, EyeOff, ExternalLink } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import type { AdInput } from '../backend';

export default function AdminAdsManager() {
  const { data: ads, isLoading } = useGetAllAds();
  const createAdMutation = useCreateAd();
  const updateAdMutation = useUpdateAd();
  const deleteAdMutation = useDeleteAd();
  const setActiveStatusMutation = useSetAdActiveStatus();

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<{ id: string; input: AdInput } | null>(null);

  const [newAd, setNewAd] = useState<AdInput>({
    imageUrl: '',
    title: '',
    link: '',
    isActive: true,
  });

  const handleCreateAd = async () => {
    if (!newAd.imageUrl || !newAd.title || !newAd.link) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      await createAdMutation.mutateAsync(newAd);
      toast.success('تم إنشاء الإعلان بنجاح');
      setIsCreateDialogOpen(false);
      setNewAd({ imageUrl: '', title: '', link: '', isActive: true });
    } catch (error) {
      toast.error('فشل إنشاء الإعلان');
    }
  };

  const handleUpdateAd = async () => {
    if (!editingAd) return;

    if (!editingAd.input.imageUrl || !editingAd.input.title || !editingAd.input.link) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      await updateAdMutation.mutateAsync({ adId: editingAd.id, adInput: editingAd.input });
      toast.success('تم تحديث الإعلان بنجاح');
      setIsEditDialogOpen(false);
      setEditingAd(null);
    } catch (error) {
      toast.error('فشل تحديث الإعلان');
    }
  };

  const handleDeleteAd = async (adId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الإعلان؟')) return;

    try {
      await deleteAdMutation.mutateAsync(adId);
      toast.success('تم حذف الإعلان بنجاح');
    } catch (error) {
      toast.error('فشل حذف الإعلان');
    }
  };

  const handleToggleActive = async (adId: string, currentStatus: boolean) => {
    try {
      await setActiveStatusMutation.mutateAsync({ adId, isActive: !currentStatus });
      toast.success(currentStatus ? 'تم إيقاف الإعلان' : 'تم تفعيل الإعلان');
    } catch (error) {
      toast.error('فشل تغيير حالة الإعلان');
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">إدارة الإعلانات</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="text-right flex-1">
            <CardTitle className="text-xl font-bold">إدارة الإعلانات</CardTitle>
            <CardDescription>إنشاء وإدارة الإعلانات الداخلية</CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-chart-1 hover:bg-chart-1/90">
                <Plus className="ml-2 h-5 w-5" />
                إعلان جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]" dir="rtl">
              <DialogHeader>
                <DialogTitle className="text-right">إنشاء إعلان جديد</DialogTitle>
                <DialogDescription className="text-right">
                  أضف إعلاناً جديداً للمستخدمين
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="new-title" className="text-right block">عنوان الإعلان</Label>
                  <Input
                    id="new-title"
                    value={newAd.title}
                    onChange={(e) => setNewAd({ ...newAd, title: e.target.value })}
                    placeholder="أدخل عنوان الإعلان"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-image" className="text-right block">رابط الصورة</Label>
                  <Input
                    id="new-image"
                    value={newAd.imageUrl}
                    onChange={(e) => setNewAd({ ...newAd, imageUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-link" className="text-right block">رابط الإعلان</Label>
                  <Input
                    id="new-link"
                    value={newAd.link}
                    onChange={(e) => setNewAd({ ...newAd, link: e.target.value })}
                    placeholder="https://example.com"
                    className="text-right"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="new-active" className="text-right">تفعيل الإعلان</Label>
                  <Switch
                    id="new-active"
                    checked={newAd.isActive}
                    onCheckedChange={(checked) => setNewAd({ ...newAd, isActive: checked })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  onClick={handleCreateAd}
                  disabled={createAdMutation.isPending}
                  className="bg-chart-1 hover:bg-chart-1/90"
                >
                  {createAdMutation.isPending ? 'جاري الإنشاء...' : 'إنشاء الإعلان'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {!ads || ads.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground font-medium">لا توجد إعلانات حتى الآن</p>
          </div>
        ) : (
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الصورة</TableHead>
                  <TableHead className="text-right">العنوان</TableHead>
                  <TableHead className="text-right">الرابط</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ads.map((ad) => (
                  <TableRow key={ad.id}>
                    <TableCell>
                      <img
                        src={ad.imageUrl}
                        alt={ad.title}
                        className="h-12 w-20 object-cover rounded"
                      />
                    </TableCell>
                    <TableCell className="text-right font-medium">{ad.title}</TableCell>
                    <TableCell className="text-right">
                      <a
                        href={ad.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-chart-1 hover:underline flex items-center gap-1"
                      >
                        <ExternalLink className="h-3 w-3" />
                        <span className="text-xs">{ad.link.slice(0, 30)}...</span>
                      </a>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleActive(ad.id, ad.isActive)}
                        disabled={setActiveStatusMutation.isPending}
                      >
                        {ad.isActive ? (
                          <Eye className="h-4 w-4 text-chart-1 ml-1" />
                        ) : (
                          <EyeOff className="h-4 w-4 text-muted-foreground ml-1" />
                        )}
                        {ad.isActive ? 'نشط' : 'متوقف'}
                      </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingAd({
                              id: ad.id,
                              input: {
                                imageUrl: ad.imageUrl,
                                title: ad.title,
                                link: ad.link,
                                isActive: ad.isActive,
                              },
                            });
                            setIsEditDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteAd(ad.id)}
                          disabled={deleteAdMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">تعديل الإعلان</DialogTitle>
            <DialogDescription className="text-right">
              قم بتحديث معلومات الإعلان
            </DialogDescription>
          </DialogHeader>
          {editingAd && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title" className="text-right block">عنوان الإعلان</Label>
                <Input
                  id="edit-title"
                  value={editingAd.input.title}
                  onChange={(e) =>
                    setEditingAd({ ...editingAd, input: { ...editingAd.input, title: e.target.value } })
                  }
                  placeholder="أدخل عنوان الإعلان"
                  className="text-right"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-image" className="text-right block">رابط الصورة</Label>
                <Input
                  id="edit-image"
                  value={editingAd.input.imageUrl}
                  onChange={(e) =>
                    setEditingAd({ ...editingAd, input: { ...editingAd.input, imageUrl: e.target.value } })
                  }
                  placeholder="https://example.com/image.jpg"
                  className="text-right"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-link" className="text-right block">رابط الإعلان</Label>
                <Input
                  id="edit-link"
                  value={editingAd.input.link}
                  onChange={(e) =>
                    setEditingAd({ ...editingAd, input: { ...editingAd.input, link: e.target.value } })
                  }
                  placeholder="https://example.com"
                  className="text-right"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="edit-active" className="text-right">تفعيل الإعلان</Label>
                <Switch
                  id="edit-active"
                  checked={editingAd.input.isActive}
                  onCheckedChange={(checked) =>
                    setEditingAd({ ...editingAd, input: { ...editingAd.input, isActive: checked } })
                  }
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              onClick={handleUpdateAd}
              disabled={updateAdMutation.isPending}
              className="bg-chart-1 hover:bg-chart-1/90"
            >
              {updateAdMutation.isPending ? 'جاري التحديث...' : 'تحديث الإعلان'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
