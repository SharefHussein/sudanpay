import { useGetPendingTransactions, useApproveTransaction, useRejectTransaction } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { CheckCircle2, XCircle, ArrowDownToLine, ArrowUpFromLine, Clock } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function PendingTransactions() {
  const { data: transactions, isLoading } = useGetPendingTransactions();
  const approveTransaction = useApproveTransaction();
  const rejectTransaction = useRejectTransaction();

  const handleApprove = async (txId: string) => {
    try {
      await approveTransaction.mutateAsync(txId);
      toast.success('تم اعتماد المعاملة بنجاح');
    } catch (error) {
      toast.error('فشل اعتماد المعاملة');
      console.error(error);
    }
  };

  const handleReject = async (txId: string) => {
    try {
      await rejectTransaction.mutateAsync(txId);
      toast.success('تم رفض المعاملة');
    } catch (error) {
      toast.error('فشل رفض المعاملة');
      console.error(error);
    }
  };

  const getTransactionIcon = (type: string) => {
    if (type === 'deposit') {
      return <ArrowDownToLine className="h-5 w-5 text-chart-1" />;
    }
    return <ArrowUpFromLine className="h-5 w-5 text-chart-2" />;
  };

  const getTransactionLabel = (type: string) => {
    if (type === 'deposit') return 'إيداع';
    if (type === 'withdrawal') return 'سحب';
    return 'رسوم';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">المعاملات المعلقة</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!transactions || transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">المعاملات المعلقة</CardTitle>
          <CardDescription className="text-right">لا توجد معاملات معلقة</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Clock className="h-5 w-5 text-chart-3" />
          المعاملات المعلقة ({transactions.length})
        </CardTitle>
        <CardDescription className="text-right">راجع واعتمد أو ارفض المعاملات</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-4">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="p-4 rounded-lg border border-chart-3/30 bg-card/50 space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="bg-accent/10 p-3 rounded-lg">
                      {getTransactionIcon(tx.transactionType.__kind__)}
                    </div>
                    <div className="flex-1 text-right">
                      <div className="font-medium text-lg">{getTransactionLabel(tx.transactionType.__kind__)}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(Number(tx.timestamp) / 1000000).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        معرف المستخدم: {tx.userId.toString().slice(0, 20)}...
                      </div>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="text-xl font-bold">{tx.amount.toFixed(2)} SDG</div>
                    <Badge variant="outline" className="border-chart-3 text-chart-3 mt-1">
                      <Clock className="h-3 w-3 ml-1" />
                      معلق
                    </Badge>
                  </div>
                </div>

                {tx.transactionType.__kind__ === 'deposit' && (
                  <div className="bg-accent/5 p-3 rounded text-right text-sm">
                    <div className="text-muted-foreground">تفاصيل:</div>
                    <div className="mt-1">{tx.transactionType.deposit.details}</div>
                  </div>
                )}

                {tx.transactionType.__kind__ === 'withdrawal' && (
                  <div className="bg-accent/5 p-3 rounded text-right text-sm">
                    <div className="text-muted-foreground">الوجهة:</div>
                    <div className="mt-1">{tx.transactionType.withdrawal.destination}</div>
                  </div>
                )}

                <div className="bg-accent/10 p-3 rounded text-right text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">رسوم العمولة:</span>
                    <span className="font-medium text-primary">{tx.commissionFee.toFixed(2)} SDG</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleApprove(tx.id)}
                    disabled={approveTransaction.isPending || rejectTransaction.isPending}
                    className="flex-1 bg-chart-1 hover:bg-chart-1/90"
                  >
                    <CheckCircle2 className="h-4 w-4 ml-2" />
                    اعتماد
                  </Button>
                  <Button
                    onClick={() => handleReject(tx.id)}
                    disabled={approveTransaction.isPending || rejectTransaction.isPending}
                    variant="destructive"
                    className="flex-1"
                  >
                    <XCircle className="h-4 w-4 ml-2" />
                    رفض
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
