import { useGetAdminWalletBalance, useGetAllUsers, useGetPendingTransactions, useGetAllTransactions } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import { Wallet, Users, Clock, TrendingUp } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminOverview() {
  const { data: adminBalance, isLoading: balanceLoading } = useGetAdminWalletBalance();
  const { data: allUsers, isLoading: usersLoading } = useGetAllUsers();
  const { data: pendingTx, isLoading: pendingLoading } = useGetPendingTransactions();
  const { data: allTransactions } = useGetAllTransactions();

  const approvedTransactions = allTransactions?.filter((tx) => tx.status === 'approved') || [];
  const totalVolume = approvedTransactions.reduce((sum, tx) => sum + tx.amount, 0);

  const chartData = [
    { name: 'الإيداعات', value: approvedTransactions.filter((tx) => tx.transactionType.__kind__ === 'deposit').length },
    { name: 'السحوبات', value: approvedTransactions.filter((tx) => tx.transactionType.__kind__ === 'withdrawal').length },
    { name: 'قيد المراجعة', value: pendingTx?.length || 0 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي العمولات</CardTitle>
            <div className="bg-primary/10 p-2 rounded-lg">
              <Wallet className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            {balanceLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div className="text-2xl font-bold">{adminBalance?.toFixed(2)} SDG</div>
            )}
          </CardContent>
        </Card>

        <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">عدد المستخدمين</CardTitle>
            <div className="bg-chart-1/10 p-2 rounded-lg">
              <Users className="h-4 w-4 text-chart-1" />
            </div>
          </CardHeader>
          <CardContent>
            {usersLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{allUsers?.length || 0}</div>
            )}
          </CardContent>
        </Card>

        <Card className="border-chart-3/20 bg-gradient-to-br from-card to-chart-3/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">معاملات معلقة</CardTitle>
            <div className="bg-chart-3/10 p-2 rounded-lg">
              <Clock className="h-4 w-4 text-chart-3" />
            </div>
          </CardHeader>
          <CardContent>
            {pendingLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{pendingTx?.length || 0}</div>
            )}
          </CardContent>
        </Card>

        <Card className="border-chart-2/20 bg-gradient-to-br from-card to-chart-2/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">حجم المعاملات</CardTitle>
            <div className="bg-chart-2/10 p-2 rounded-lg">
              <TrendingUp className="h-4 w-4 text-chart-2" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalVolume.toFixed(2)} SDG</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-right">إحصائيات المعاملات</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              value: {
                label: 'العدد',
                color: 'oklch(var(--chart-1))',
              },
            }}
            className="h-[300px]"
          >
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--border))" />
              <XAxis dataKey="name" stroke="oklch(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="oklch(var(--muted-foreground))" fontSize={12} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="value" fill="oklch(var(--chart-1))" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
}
