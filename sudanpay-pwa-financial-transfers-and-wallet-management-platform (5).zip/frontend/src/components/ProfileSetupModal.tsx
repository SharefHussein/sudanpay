import { useState } from 'react';
import { useCreateUserProfile } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { UserCircle } from 'lucide-react';

export default function ProfileSetupModal() {
  const [name, setName] = useState('');
  const [arabicName, setArabicName] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const createProfile = useCreateUserProfile();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !arabicName.trim() || !contactInfo.trim()) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      await createProfile.mutateAsync({ name, contactInfo, arabicName });
      toast.success('تم إنشاء الملف الشخصي بنجاح');
    } catch (error) {
      toast.error('فشل إنشاء الملف الشخصي');
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-primary/30 bg-card/80 backdrop-blur shadow-2xl">
        <CardHeader className="text-center">
          <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserCircle className="h-10 w-10 text-primary" />
          </div>
          <CardTitle className="text-2xl">إعداد الملف الشخصي</CardTitle>
          <CardDescription>أكمل معلوماتك للبدء</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="arabicName" className="text-right block">الاسم بالعربية</Label>
              <Input
                id="arabicName"
                value={arabicName}
                onChange={(e) => setArabicName(e.target.value)}
                placeholder="أدخل اسمك بالعربية"
                className="text-right"
                dir="rtl"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name" className="text-right block">الاسم بالإنجليزية</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name in English"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contactInfo" className="text-right block">معلومات الاتصال</Label>
              <Input
                id="contactInfo"
                value={contactInfo}
                onChange={(e) => setContactInfo(e.target.value)}
                placeholder="رقم الهاتف أو البريد الإلكتروني"
                className="text-right"
                dir="rtl"
              />
            </div>

            <Button
              type="submit"
              className="w-full h-11 bg-gradient-to-r from-primary to-chart-1"
              disabled={createProfile.isPending}
            >
              {createProfile.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                  جاري الحفظ...
                </>
              ) : (
                'حفظ ومتابعة'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
