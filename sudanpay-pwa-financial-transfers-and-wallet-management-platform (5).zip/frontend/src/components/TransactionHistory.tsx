import { useGetCallerTransactions } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowDownToLine, ArrowUpFromLine, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function TransactionHistory() {
  const { data: transactions, isLoading } = useGetCallerTransactions();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-chart-1/20 text-chart-1 hover:bg-chart-1/30"><CheckCircle2 className="h-3 w-3 ml-1" />معتمد</Badge>;
      case 'pending':
        return <Badge variant="outline" className="border-chart-3 text-chart-3"><Clock className="h-3 w-3 ml-1" />قيد المراجعة</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 ml-1" />مرفوض</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTransactionIcon = (type: string) => {
    if (type === 'deposit') {
      return <ArrowDownToLine className="h-5 w-5 text-chart-1" />;
    }
    return <ArrowUpFromLine className="h-5 w-5 text-chart-2" />;
  };

  const getTransactionLabel = (type: string) => {
    if (type === 'deposit') return 'إيداع';
    if (type === 'withdrawal') return 'سحب';
    return 'رسوم';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">سجل المعاملات</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!transactions || transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">سجل المعاملات</CardTitle>
          <CardDescription className="text-right">لا توجد معاملات حتى الآن</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right">سجل المعاملات</CardTitle>
        <CardDescription className="text-right">جميع معاملاتك المالية</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-4">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-card/50 hover:bg-accent/5 transition-colors"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="bg-accent/10 p-3 rounded-lg">
                    {getTransactionIcon(tx.transactionType.__kind__)}
                  </div>
                  <div className="flex-1 text-right">
                    <div className="font-medium">{getTransactionLabel(tx.transactionType.__kind__)}</div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(Number(tx.timestamp) / 1000000).toLocaleDateString('ar-SA', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                    {tx.commissionFee > 0 && (
                      <div className="text-xs text-muted-foreground mt-1">
                        رسوم: {tx.commissionFee.toFixed(2)} SDG
                      </div>
                    )}
                  </div>
                </div>
                <div className="text-left space-y-2">
                  <div className="text-lg font-bold">
                    {tx.transactionType.__kind__ === 'withdrawal' ? '-' : '+'}
                    {tx.amount.toFixed(2)} SDG
                  </div>
                  {getStatusBadge(tx.status)}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
