import { useGetCallerTransactions } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import { TrendingUp } from 'lucide-react';

export default function BalanceChart() {
  const { data: transactions, isLoading } = useGetCallerTransactions();

  const chartData = transactions
    ?.filter((tx) => tx.status === 'approved')
    .sort((a, b) => Number(a.timestamp) - Number(b.timestamp))
    .reduce((acc, tx) => {
      const lastBalance = acc.length > 0 ? acc[acc.length - 1].balance : 0;
      let newBalance = lastBalance;

      if (tx.transactionType.__kind__ === 'deposit') {
        newBalance += tx.amount;
      } else if (tx.transactionType.__kind__ === 'withdrawal') {
        newBalance -= tx.amount;
      }

      const date = new Date(Number(tx.timestamp) / 1000000);
      acc.push({
        date: date.toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' }),
        balance: newBalance,
      });
      return acc;
    }, [] as Array<{ date: string; balance: number }>)
    .slice(-10) || [];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">تطور الرصيد</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="text-muted-foreground">جاري التحميل...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-right">تطور الرصيد</CardTitle>
          <CardDescription className="text-right">لا توجد بيانات كافية لعرض الرسم البياني</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-chart-1" />
          تطور الرصيد
        </CardTitle>
        <CardDescription className="text-right">آخر 10 معاملات معتمدة</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            balance: {
              label: 'الرصيد',
              color: 'oklch(var(--chart-1))',
            },
          }}
          className="h-[300px]"
        >
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="oklch(var(--chart-1))" stopOpacity={0.3} />
                <stop offset="95%" stopColor="oklch(var(--chart-1))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--border))" />
            <XAxis dataKey="date" stroke="oklch(var(--muted-foreground))" fontSize={12} />
            <YAxis stroke="oklch(var(--muted-foreground))" fontSize={12} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Area
              type="monotone"
              dataKey="balance"
              stroke="oklch(var(--chart-1))"
              strokeWidth={2}
              fill="url(#colorBalance)"
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
