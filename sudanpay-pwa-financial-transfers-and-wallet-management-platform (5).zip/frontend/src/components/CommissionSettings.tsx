import { useState, useEffect } from 'react';
import { useGetCommissionConfig, useUpdateCommissionConfig } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Settings, Save } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function CommissionSettings() {
  const { data: config, isLoading } = useGetCommissionConfig();
  const updateConfig = useUpdateCommissionConfig();
  const [depositFee, setDepositFee] = useState('');
  const [withdrawalFee, setWithdrawalFee] = useState('');

  useEffect(() => {
    if (config) {
      setDepositFee((config.depositFee * 100).toFixed(2));
      setWithdrawalFee((config.withdrawalFee * 100).toFixed(2));
    }
  }, [config]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const depositFeeNum = parseFloat(depositFee) / 100;
    const withdrawalFeeNum = parseFloat(withdrawalFee) / 100;

    if (isNaN(depositFeeNum) || isNaN(withdrawalFeeNum)) {
      toast.error('يرجى إدخال قيم صحيحة');
      return;
    }

    if (depositFeeNum < 0 || depositFeeNum > 1 || withdrawalFeeNum < 0 || withdrawalFeeNum > 1) {
      toast.error('يجب أن تكون النسبة بين 0% و 100%');
      return;
    }

    try {
      await updateConfig.mutateAsync({ depositFee: depositFeeNum, withdrawalFee: withdrawalFeeNum });
      toast.success('تم تحديث إعدادات العمولة بنجاح');
    } catch (error) {
      toast.error('فشل تحديث إعدادات العمولة');
      console.error(error);
    }
  };

  if (isLoading) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-right">إعدادات العمولة</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          إعدادات العمولة
        </CardTitle>
        <CardDescription className="text-right">
          تحديد نسب العمولة على الإيداعات والسحوبات
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="depositFee" className="text-right block">عمولة الإيداع (%)</Label>
            <Input
              id="depositFee"
              type="number"
              step="0.01"
              value={depositFee}
              onChange={(e) => setDepositFee(e.target.value)}
              placeholder="2.00"
              className="text-right text-lg"
              dir="rtl"
            />
            <p className="text-sm text-muted-foreground text-right">
              النسبة الحالية: {config ? (config.depositFee * 100).toFixed(2) : '0'}%
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="withdrawalFee" className="text-right block">عمولة السحب (%)</Label>
            <Input
              id="withdrawalFee"
              type="number"
              step="0.01"
              value={withdrawalFee}
              onChange={(e) => setWithdrawalFee(e.target.value)}
              placeholder="3.00"
              className="text-right text-lg"
              dir="rtl"
            />
            <p className="text-sm text-muted-foreground text-right">
              النسبة الحالية: {config ? (config.withdrawalFee * 100).toFixed(2) : '0'}%
            </p>
          </div>

          <Button
            type="submit"
            className="w-full h-11 bg-gradient-to-r from-primary to-chart-1"
            disabled={updateConfig.isPending}
          >
            {updateConfig.isPending ? (
              <>
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                جاري الحفظ...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 ml-2" />
                حفظ التغييرات
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
