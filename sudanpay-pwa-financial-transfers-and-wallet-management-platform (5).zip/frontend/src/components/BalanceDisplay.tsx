import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface BalanceDisplayProps {
  balance: number | undefined;
  isLoading: boolean;
  size?: 'sm' | 'md' | 'lg';
  showCurrency?: boolean;
  className?: string;
}

export default function BalanceDisplay({ 
  balance, 
  isLoading, 
  size = 'lg',
  showCurrency = true,
  className = ''
}: BalanceDisplayProps) {
  const [isVisible, setIsVisible] = useState(false);

  const sizeClasses = {
    sm: 'text-xl',
    md: 'text-2xl',
    lg: 'text-3xl'
  };

  const toggleVisibility = () => {
    setIsVisible(!isVisible);
  };

  if (isLoading) {
    return <Skeleton className={`h-10 w-40 ${className}`} />;
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`${sizeClasses[size]} font-bold`}>
        {isVisible ? (
          <>
            {balance?.toFixed(2)}{' '}
            {showCurrency && <span className="text-muted-foreground text-lg">SDG</span>}
          </>
        ) : (
          <span className="select-none">••••••</span>
        )}
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleVisibility}
        className="h-8 w-8"
        aria-label={isVisible ? 'إخفاء الرصيد' : 'إظهار الرصيد'}
      >
        {isVisible ? (
          <EyeOff className="h-4 w-4 text-muted-foreground" />
        ) : (
          <Eye className="h-4 w-4 text-muted-foreground" />
        )}
      </Button>
    </div>
  );
}
