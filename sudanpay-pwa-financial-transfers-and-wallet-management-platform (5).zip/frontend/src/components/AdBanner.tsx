import { useGetActiveAds } from '../hooks/useQueries';
import { Card, CardContent } from '@/components/ui/card';
import { ExternalLink } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function AdBanner() {
  const { data: ads, isLoading } = useGetActiveAds();
  const [currentAdIndex, setCurrentAdIndex] = useState(0);

  // Rotate ads every 10 seconds
  useEffect(() => {
    if (!ads || ads.length === 0) return;

    const interval = setInterval(() => {
      setCurrentAdIndex((prev) => (prev + 1) % ads.length);
    }, 10000);

    return () => clearInterval(interval);
  }, [ads]);

  if (isLoading || !ads || ads.length === 0) {
    return null;
  }

  const currentAd = ads[currentAdIndex];

  return (
    <Card className="border-chart-3/30 bg-gradient-to-br from-card to-chart-3/10 shadow-md overflow-hidden">
      <CardContent className="p-0">
        <a
          href={currentAd.link}
          target="_blank"
          rel="noopener noreferrer"
          className="block hover:opacity-90 transition-opacity"
        >
          <div className="relative">
            <img
              src={currentAd.imageUrl}
              alt={currentAd.title}
              className="w-full h-32 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-bold text-lg text-right flex-1">{currentAd.title}</h3>
                <ExternalLink className="h-5 w-5 shrink-0" />
              </div>
            </div>
          </div>
        </a>
        {ads.length > 1 && (
          <div className="flex justify-center gap-2 py-3 bg-muted/20">
            {ads.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentAdIndex(index)}
                className={`h-2 rounded-full transition-all ${
                  index === currentAdIndex ? 'w-8 bg-chart-3' : 'w-2 bg-muted-foreground/30'
                }`}
                aria-label={`عرض الإعلان ${index + 1}`}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
