import WalletOverview from '../components/WalletOverview';
import BalanceChart from '../components/BalanceChart';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Zap, TrendingUp } from 'lucide-react';

export default function WalletPage() {
  return (
    <div className="space-y-6">
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">المحفظة</h2>
        <p className="text-muted-foreground">إدارة رصيدك ومعاملاتك المالية</p>
      </div>

      <WalletOverview />

      <BalanceChart />

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
          <CardHeader>
            <div className="bg-chart-1/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <Shield className="h-6 w-6 text-chart-1" />
            </div>
            <CardTitle className="text-right text-lg">حماية متقدمة</CardTitle>
            <CardDescription className="text-right text-sm">
              محفظتك محمية بأحدث تقنيات الأمان
            </CardDescription>
          </CardHeader>
        </Card>

        <Card className="border-chart-2/20 bg-gradient-to-br from-card to-chart-2/5">
          <CardHeader>
            <div className="bg-chart-2/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <Zap className="h-6 w-6 text-chart-2" />
            </div>
            <CardTitle className="text-right text-lg">معاملات فورية</CardTitle>
            <CardDescription className="text-right text-sm">
              تنفيذ سريع لجميع العمليات المالية
            </CardDescription>
          </CardHeader>
        </Card>

        <Card className="border-chart-3/20 bg-gradient-to-br from-card to-chart-3/5">
          <CardHeader>
            <div className="bg-chart-3/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <TrendingUp className="h-6 w-6 text-chart-3" />
            </div>
            <CardTitle className="text-right text-lg">رسوم تنافسية</CardTitle>
            <CardDescription className="text-right text-sm">
              أفضل الأسعار في السوق
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
