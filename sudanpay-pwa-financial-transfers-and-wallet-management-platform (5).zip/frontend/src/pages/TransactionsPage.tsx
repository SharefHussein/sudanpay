import TransactionHistory from '../components/TransactionHistory';

export default function TransactionsPage() {
  return (
    <div className="space-y-6">
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">المعاملات</h2>
        <p className="text-muted-foreground">سجل جميع معاملاتك المالية</p>
      </div>

      <TransactionHistory />
    </div>
  );
}
