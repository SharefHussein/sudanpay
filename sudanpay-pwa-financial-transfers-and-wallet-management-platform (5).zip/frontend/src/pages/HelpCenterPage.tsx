import { useState } from 'react';
import { useSeo } from '../hooks/useSeo';
import { useGetAllFaqs, useCreateSupportTicket } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../components/ui/accordion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Skeleton } from '../components/ui/skeleton';
import { HelpCircle, MessageCircle, Search, Send } from 'lucide-react';
import { toast } from 'sonner';

export default function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [activeLanguage, setActiveLanguage] = useState<'ar' | 'en'>('ar');

  const { data: faqs = [], isLoading } = useGetAllFaqs();
  const createTicket = useCreateSupportTicket();

  useSeo({
    title: 'مركز المساعدة - سودان باي | Help Center - SudanPay',
    titleEn: 'Help Center - SudanPay',
    description: 'الأسئلة الشائعة والدعم الفني لمنصة سودان باي. احصل على المساعدة في الإيداع والسحب والتحويلات.',
    descriptionEn: 'FAQs and technical support for SudanPay platform. Get help with deposits, withdrawals, and transfers.',
    keywords: ['مساعدة', 'دعم', 'أسئلة شائعة', 'FAQ', 'help', 'support'],
    canonicalUrl: 'https://sudanpay.app/help',
    ogImage: 'https://sudanpay.app/assets/generated/sudanpay-logo-transparent.dim_200x200.png',
  });

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim()) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      await createTicket.mutateAsync({
        subject: ticketSubject,
        message: ticketMessage,
      });
      toast.success('تم إرسال طلب الدعم بنجاح');
      setTicketSubject('');
      setTicketMessage('');
    } catch (error) {
      toast.error('فشل إرسال طلب الدعم');
    }
  };

  const filteredFaqs = faqs.filter((faq) => {
    const question = activeLanguage === 'ar' ? faq.questionAr : faq.questionEn;
    const answer = activeLanguage === 'ar' ? faq.answerAr : faq.answerEn;
    return (
      question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      answer.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const categories = Array.from(new Set(faqs.map((faq) => faq.category)));

  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-br from-primary/10 via-background to-background border-primary/20">
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center gap-3">
            <HelpCircle className="h-8 w-8 text-primary" />
            مركز المساعدة
          </CardTitle>
          <p className="text-muted-foreground mt-2">
            نحن هنا لمساعدتك. ابحث عن إجابات لأسئلتك أو تواصل معنا مباشرة.
          </p>
        </CardHeader>
      </Card>

      {/* Search Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="ابحث عن سؤال..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 text-lg h-12"
            />
          </div>
        </CardContent>
      </Card>

      {/* Language Toggle */}
      <div className="flex justify-center">
        <Tabs value={activeLanguage} onValueChange={(v) => setActiveLanguage(v as 'ar' | 'en')} className="w-full max-w-md">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="ar">العربية</TabsTrigger>
            <TabsTrigger value="en">English</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* FAQs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" />
            الأسئلة الشائعة
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredFaqs.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <HelpCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>لم يتم العثور على أسئلة</p>
            </div>
          ) : (
            <Tabs defaultValue={categories[0] || 'all'} className="w-full">
              <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto">
                <TabsTrigger value="all">الكل</TabsTrigger>
                {categories.map((category) => (
                  <TabsTrigger key={category} value={category}>
                    {category === 'deposits' && 'الإيداعات'}
                    {category === 'withdrawals' && 'السحوبات'}
                    {category === 'transfers' && 'التحويلات'}
                    {category === 'fees' && 'الرسوم'}
                    {category === 'wallet' && 'المحفظة'}
                    {category === 'account' && 'الحساب'}
                  </TabsTrigger>
                ))}
              </TabsList>

              <TabsContent value="all" className="mt-6">
                <Accordion type="single" collapsible className="w-full">
                  {filteredFaqs.map((faq) => (
                    <AccordionItem key={faq.id} value={faq.id}>
                      <AccordionTrigger className="text-right text-base font-medium">
                        {activeLanguage === 'ar' ? faq.questionAr : faq.questionEn}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground leading-relaxed">
                        {activeLanguage === 'ar' ? faq.answerAr : faq.answerEn}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </TabsContent>

              {categories.map((category) => (
                <TabsContent key={category} value={category} className="mt-6">
                  <Accordion type="single" collapsible className="w-full">
                    {filteredFaqs
                      .filter((faq) => faq.category === category)
                      .map((faq) => (
                        <AccordionItem key={faq.id} value={faq.id}>
                          <AccordionTrigger className="text-right text-base font-medium">
                            {activeLanguage === 'ar' ? faq.questionAr : faq.questionEn}
                          </AccordionTrigger>
                          <AccordionContent className="text-muted-foreground leading-relaxed">
                            {activeLanguage === 'ar' ? faq.answerAr : faq.answerEn}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                  </Accordion>
                </TabsContent>
              ))}
            </Tabs>
          )}
        </CardContent>
      </Card>

      {/* Support Ticket Form */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-primary" />
            تواصل مع الدعم الفني
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            لم تجد إجابة لسؤالك؟ أرسل لنا رسالة وسنرد عليك في أقرب وقت ممكن.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitTicket} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="subject">الموضوع</Label>
              <Input
                id="subject"
                placeholder="اكتب موضوع رسالتك..."
                value={ticketSubject}
                onChange={(e) => setTicketSubject(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">الرسالة</Label>
              <Textarea
                id="message"
                placeholder="اكتب رسالتك هنا..."
                value={ticketMessage}
                onChange={(e) => setTicketMessage(e.target.value)}
                rows={6}
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-chart-3 hover:opacity-90"
              size="lg"
              disabled={createTicket.isPending}
            >
              {createTicket.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent ml-2" />
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <Send className="h-5 w-5 ml-2" />
                  إرسال الرسالة
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
