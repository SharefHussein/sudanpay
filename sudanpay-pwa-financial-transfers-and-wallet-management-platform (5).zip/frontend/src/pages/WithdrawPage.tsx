import WithdrawalForm from '../components/WithdrawalForm';

export default function WithdrawPage() {
  return (
    <div className="space-y-6">
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">سحب</h2>
        <p className="text-muted-foreground">سحب رصيد من محفظتك</p>
      </div>

      <WithdrawalForm />
    </div>
  );
}
