import DepositForm from '../components/DepositForm';

export default function DepositPage() {
  return (
    <div className="space-y-6">
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">إيداع</h2>
        <p className="text-muted-foreground">إضافة رصيد إلى محفظتك</p>
      </div>

      <DepositForm />
    </div>
  );
}
