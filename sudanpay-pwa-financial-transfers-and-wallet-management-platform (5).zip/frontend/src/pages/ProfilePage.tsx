import { useGetCallerUserProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { User, Mail, Shield, Key } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function ProfilePage() {
  const { data: userProfile, isLoading } = useGetCallerUserProfile();
  const { identity } = useInternetIdentity();

  const initials = userProfile?.arabicName?.slice(0, 2) || userProfile?.name?.slice(0, 2) || 'مس';
  const principalId = identity?.getPrincipal().toString() || '';

  return (
    <div className="space-y-6">
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">الملف الشخصي</h2>
        <p className="text-muted-foreground">معلومات حسابك الشخصية</p>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="pt-6 space-y-4">
            <Skeleton className="h-24 w-24 rounded-full mx-auto" />
            <Skeleton className="h-8 w-48 mx-auto" />
            <Skeleton className="h-4 w-64 mx-auto" />
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Profile Header */}
          <Card className="border-primary/20 bg-gradient-to-br from-card via-card to-primary/5">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <Avatar className="h-24 w-24 border-4 border-primary/20">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-chart-1 text-primary-foreground text-3xl">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-2xl font-bold">{userProfile?.arabicName}</h3>
                  <p className="text-muted-foreground">{userProfile?.name}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-right">معلومات الحساب</CardTitle>
              <CardDescription className="text-right">تفاصيل حسابك الشخصية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4" dir="rtl">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-sm text-muted-foreground">الاسم بالعربية</p>
                    <p className="font-medium">{userProfile?.arabicName}</p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4" dir="rtl">
                  <div className="bg-chart-1/10 p-3 rounded-lg">
                    <User className="h-5 w-5 text-chart-1" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-sm text-muted-foreground">الاسم بالإنجليزية</p>
                    <p className="font-medium">{userProfile?.name}</p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4" dir="rtl">
                  <div className="bg-chart-2/10 p-3 rounded-lg">
                    <Mail className="h-5 w-5 text-chart-2" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-sm text-muted-foreground">معلومات الاتصال</p>
                    <p className="font-medium">{userProfile?.contactInfo}</p>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4" dir="rtl">
                  <div className="bg-chart-3/10 p-3 rounded-lg">
                    <Key className="h-5 w-5 text-chart-3" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-sm text-muted-foreground">معرف الحساب</p>
                    <p className="font-mono text-xs break-all">{principalId}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security Info */}
          <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="bg-chart-1/10 p-2 rounded-lg">
                  <Shield className="h-5 w-5 text-chart-1" />
                </div>
                <div className="text-right flex-1">
                  <CardTitle className="text-lg">حساب محمي</CardTitle>
                  <CardDescription className="text-sm">
                    حسابك محمي بتقنية Internet Identity
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>
        </>
      )}
    </div>
  );
}
