import { useGetCallerWalletBalance, useGetCallerTransactions } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wallet, TrendingUp, ArrowDownToLine, ArrowUpFromLine, Activity } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from '@tanstack/react-router';
import BalanceChart from '../components/BalanceChart';
import { Badge } from '@/components/ui/badge';

export default function HomePage() {
  const { data: balance, isLoading: balanceLoading } = useGetCallerWalletBalance();
  const { data: transactions, isLoading: transactionsLoading } = useGetCallerTransactions();
  const navigate = useNavigate();

  const recentTransactions = transactions?.slice(0, 5) || [];
  const pendingCount = transactions?.filter(tx => tx.status === 'pending').length || 0;

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="text-right">
        <h2 className="text-3xl font-bold mb-2">مرحباً بك</h2>
        <p className="text-muted-foreground">نظرة عامة على حسابك</p>
      </div>

      {/* Balance Card */}
      <Card className="border-primary/20 bg-gradient-to-br from-card via-card to-primary/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">الرصيد الإجمالي</CardTitle>
          <div className="bg-primary/10 p-2 rounded-lg">
            <Wallet className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          {balanceLoading ? (
            <Skeleton className="h-12 w-48" />
          ) : (
            <div className="space-y-1">
              <div className="text-4xl font-bold tracking-tight">
                {balance?.toFixed(2)} <span className="text-2xl text-muted-foreground">SDG</span>
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-chart-1" />
                متاح للسحب
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          onClick={() => navigate({ to: '/deposit' })}
          className="h-24 flex flex-col gap-2 bg-gradient-to-br from-chart-1 to-chart-1/80"
          size="lg"
        >
          <ArrowDownToLine className="h-6 w-6" />
          <span>إيداع</span>
        </Button>
        <Button
          onClick={() => navigate({ to: '/withdraw' })}
          className="h-24 flex flex-col gap-2 bg-gradient-to-br from-chart-2 to-chart-2/80"
          size="lg"
        >
          <ArrowUpFromLine className="h-6 w-6" />
          <span>سحب</span>
        </Button>
      </div>

      {/* Pending Transactions Alert */}
      {pendingCount > 0 && (
        <Card className="border-chart-3/50 bg-chart-3/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="text-right flex-1">
                <p className="font-medium">لديك {pendingCount} معاملة قيد المراجعة</p>
                <p className="text-sm text-muted-foreground">سيتم مراجعتها قريباً</p>
              </div>
              <Activity className="h-8 w-8 text-chart-3" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Balance Chart */}
      <BalanceChart />

      {/* Recent Transactions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-right">آخر المعاملات</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate({ to: '/transactions' })}
          >
            عرض الكل
          </Button>
        </CardHeader>
        <CardContent>
          {transactionsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : recentTransactions.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">لا توجد معاملات حتى الآن</p>
          ) : (
            <div className="space-y-3">
              {recentTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card/50"
                >
                  <div className="flex items-center gap-3 flex-1">
                    <div className="bg-accent/10 p-2 rounded-lg">
                      {tx.transactionType.__kind__ === 'deposit' ? (
                        <ArrowDownToLine className="h-4 w-4 text-chart-1" />
                      ) : (
                        <ArrowUpFromLine className="h-4 w-4 text-chart-2" />
                      )}
                    </div>
                    <div className="text-right flex-1">
                      <div className="font-medium text-sm">
                        {tx.transactionType.__kind__ === 'deposit' ? 'إيداع' : 'سحب'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(Number(tx.timestamp) / 1000000).toLocaleDateString('ar-SA')}
                      </div>
                    </div>
                  </div>
                  <div className="text-left space-y-1">
                    <div className="text-sm font-bold">
                      {tx.transactionType.__kind__ === 'withdrawal' ? '-' : '+'}
                      {tx.amount.toFixed(2)} SDG
                    </div>
                    <Badge
                      variant={tx.status === 'approved' ? 'default' : tx.status === 'pending' ? 'outline' : 'destructive'}
                      className="text-[10px]"
                    >
                      {tx.status === 'approved' ? 'معتمد' : tx.status === 'pending' ? 'قيد المراجعة' : 'مرفوض'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
