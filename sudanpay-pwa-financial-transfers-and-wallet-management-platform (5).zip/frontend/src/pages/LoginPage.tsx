import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Shield, Zap } from 'lucide-react';

export default function LoginPage() {
  const { login, isLoggingIn } = useInternetIdentity();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <img 
              src="/assets/generated/sudanpay-logo-transparent.dim_200x200.png" 
              alt="SudanPay Logo" 
              className="h-24 w-24"
            />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-chart-1 to-chart-2 bg-clip-text text-transparent">
            سودان باي
          </h1>
          <p className="text-xl text-muted-foreground">منصة التداول والمحفظة الرقمية</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="border-primary/20 bg-card/50 backdrop-blur">
            <CardHeader>
              <div className="bg-chart-1/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-chart-1" />
              </div>
              <CardTitle className="text-right">تداول آمن وسريع</CardTitle>
              <CardDescription className="text-right">
                نظام تداول متقدم مع رسوم تنافسية وتنفيذ فوري للمعاملات
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-primary/20 bg-card/50 backdrop-blur">
            <CardHeader>
              <div className="bg-chart-2/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-chart-2" />
              </div>
              <CardTitle className="text-right">حماية متقدمة</CardTitle>
              <CardDescription className="text-right">
                تأمين عالي المستوى باستخدام تقنية Internet Identity
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        <Card className="max-w-md mx-auto border-primary/30 bg-card/80 backdrop-blur shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">تسجيل الدخول</CardTitle>
            <CardDescription>ابدأ التداول الآن مع سودان باي</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Button
              onClick={login}
              disabled={isLoggingIn}
              className="w-full h-12 text-lg bg-gradient-to-r from-primary to-chart-1 hover:opacity-90 transition-opacity"
              size="lg"
            >
              {isLoggingIn ? (
                <>
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent mr-2" />
                  جاري تسجيل الدخول...
                </>
              ) : (
                <>
                  <Zap className="ml-2 h-5 w-5" />
                  تسجيل الدخول
                </>
              )}
            </Button>

            <div className="text-center text-sm text-muted-foreground">
              <p>تسجيل الدخول آمن ومشفر بالكامل</p>
            </div>
          </CardContent>
        </Card>

        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p>© 2025. بُني بحب باستخدام <a href="https://caffeine.ai" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">caffeine.ai</a></p>
        </footer>
      </div>
    </div>
  );
}
