import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Header from '../components/Header';
import AdminOverview from '../components/AdminOverview';
import PendingTransactions from '../components/PendingTransactions';
import AllUsersView from '../components/AllUsersView';
import CommissionSettings from '../components/CommissionSettings';
import { LayoutDashboard, Clock, Users, Settings } from 'lucide-react';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-background">
      <Header isAdmin />
      
      <main className="container mx-auto px-4 py-6 max-w-7xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 h-auto p-1 bg-card/50 backdrop-blur">
            <TabsTrigger value="overview" className="flex flex-col sm:flex-row items-center gap-2 py-3">
              <LayoutDashboard className="h-4 w-4" />
              <span className="text-xs sm:text-sm">لوحة التحكم</span>
            </TabsTrigger>
            <TabsTrigger value="pending" className="flex flex-col sm:flex-row items-center gap-2 py-3">
              <Clock className="h-4 w-4" />
              <span className="text-xs sm:text-sm">المعاملات</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex flex-col sm:flex-row items-center gap-2 py-3">
              <Users className="h-4 w-4" />
              <span className="text-xs sm:text-sm">المستخدمين</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex flex-col sm:flex-row items-center gap-2 py-3">
              <Settings className="h-4 w-4" />
              <span className="text-xs sm:text-sm">الإعدادات</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <AdminOverview />
          </TabsContent>

          <TabsContent value="pending">
            <PendingTransactions />
          </TabsContent>

          <TabsContent value="users">
            <AllUsersView />
          </TabsContent>

          <TabsContent value="settings">
            <CommissionSettings />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
