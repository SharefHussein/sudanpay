import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, Transaction, CommissionConfig } from '../backend';
import { Principal } from '@icp-sdk/core/principal';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useCreateUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: { name: string; contactInfo: string; arabicName: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createUserProfile(profile.name, profile.contactInfo, profile.arabicName);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetCallerWalletBalance() {
  const { actor, isFetching } = useActor();

  return useQuery<number>({
    queryKey: ['walletBalance'],
    queryFn: async () => {
      if (!actor) return 0;
      return actor.getCallerWalletBalance();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useGetCallerTransactions() {
  const { actor, isFetching } = useActor();

  return useQuery<Transaction[]>({
    queryKey: ['userTransactions'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getCallerTransactions();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useSubmitDepositRequest() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ amount, details }: { amount: number; details: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitDepositRequest(amount, details);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userTransactions'] });
    },
  });
}

export function useSubmitWithdrawalRequest() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ amount, destination }: { amount: number; destination: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitWithdrawalRequest(amount, destination);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userTransactions'] });
      queryClient.invalidateQueries({ queryKey: ['walletBalance'] });
    },
  });
}

// Admin queries
export function useGetAllUsers() {
  const { actor, isFetching } = useActor();

  return useQuery<Array<[Principal, UserProfile]>>({
    queryKey: ['allUsers'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllUsers();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15000,
  });
}

export function useGetAllTransactions() {
  const { actor, isFetching } = useActor();

  return useQuery<Transaction[]>({
    queryKey: ['allTransactions'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllTransactions();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useGetPendingTransactions() {
  const { actor, isFetching } = useActor();

  return useQuery<Transaction[]>({
    queryKey: ['pendingTransactions'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPendingTransactions();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 5000,
  });
}

export function useApproveTransaction() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (transactionId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.approveTransaction(transactionId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pendingTransactions'] });
      queryClient.invalidateQueries({ queryKey: ['allTransactions'] });
      queryClient.invalidateQueries({ queryKey: ['adminWalletBalance'] });
      queryClient.invalidateQueries({ queryKey: ['totalCommissionEarnings'] });
    },
  });
}

export function useRejectTransaction() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (transactionId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.rejectTransaction(transactionId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pendingTransactions'] });
      queryClient.invalidateQueries({ queryKey: ['allTransactions'] });
    },
  });
}

export function useGetAdminWalletBalance() {
  const { actor, isFetching } = useActor();

  return useQuery<number>({
    queryKey: ['adminWalletBalance'],
    queryFn: async () => {
      if (!actor) return 0;
      return actor.getAdminWalletBalance();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useGetTotalCommissionEarnings() {
  const { actor, isFetching } = useActor();

  return useQuery<number>({
    queryKey: ['totalCommissionEarnings'],
    queryFn: async () => {
      if (!actor) return 0;
      return actor.getTotalCommissionEarnings();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useGetCommissionConfig() {
  const { actor, isFetching } = useActor();

  return useQuery<CommissionConfig>({
    queryKey: ['commissionConfig'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCommissionConfig();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useUpdateCommissionConfig() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ depositFee, withdrawalFee }: { depositFee: number; withdrawalFee: number }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateCommissionConfig(depositFee, withdrawalFee);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['commissionConfig'] });
    },
  });
}
