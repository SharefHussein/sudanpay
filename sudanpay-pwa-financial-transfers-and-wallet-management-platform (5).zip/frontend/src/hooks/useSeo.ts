import { useEffect } from 'react';

interface SeoMetadata {
  title: string;
  titleEn?: string;
  description: string;
  descriptionEn?: string;
  keywords?: string[];
  canonicalUrl?: string;
  ogImage?: string;
  ogType?: string;
}

export function useSeo(metadata: SeoMetadata) {
  useEffect(() => {
    // Update document title
    if (metadata.title) {
      document.title = metadata.title;
    }

    // Update or create meta tags
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const attribute = property ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      
      element.setAttribute('content', content);
    };

    // Primary meta tags
    if (metadata.description) {
      updateMetaTag('description', metadata.description);
    }

    if (metadata.keywords && metadata.keywords.length > 0) {
      updateMetaTag('keywords', metadata.keywords.join(', '));
    }

    // Open Graph tags
    if (metadata.title) {
      updateMetaTag('og:title', metadata.title, true);
    }

    if (metadata.description) {
      updateMetaTag('og:description', metadata.description, true);
    }

    if (metadata.ogImage) {
      updateMetaTag('og:image', metadata.ogImage, true);
    }

    if (metadata.ogType) {
      updateMetaTag('og:type', metadata.ogType, true);
    }

    if (metadata.canonicalUrl) {
      updateMetaTag('og:url', metadata.canonicalUrl, true);
    }

    // Twitter Card tags
    if (metadata.title) {
      updateMetaTag('twitter:title', metadata.title);
    }

    if (metadata.description) {
      updateMetaTag('twitter:description', metadata.description);
    }

    if (metadata.ogImage) {
      updateMetaTag('twitter:image', metadata.ogImage);
    }

    // Update canonical link
    if (metadata.canonicalUrl) {
      let canonicalLink = document.querySelector('link[rel="canonical"]');
      
      if (!canonicalLink) {
        canonicalLink = document.createElement('link');
        canonicalLink.setAttribute('rel', 'canonical');
        document.head.appendChild(canonicalLink);
      }
      
      canonicalLink.setAttribute('href', metadata.canonicalUrl);
    }
  }, [metadata]);
}

export function useStructuredData(schemaType: string, data: Record<string, any>) {
  useEffect(() => {
    const scriptId = `structured-data-${schemaType}`;
    let script = document.getElementById(scriptId) as HTMLScriptElement;

    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    script.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      ...data,
    });

    return () => {
      const existingScript = document.getElementById(scriptId);
      if (existingScript) {
        existingScript.remove();
      }
    };
  }, [schemaType, data]);
}
