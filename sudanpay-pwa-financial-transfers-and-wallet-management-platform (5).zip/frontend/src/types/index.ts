import { Principal } from '@icp-sdk/core/principal';

// Authentication Types
export type AuthMethod =
  | { __kind__: 'email'; email: string }
  | { __kind__: 'phone'; phone: string }
  | { __kind__: 'internetIdentity' };

export interface RegistrationInput {
  password: string;
  name: string;
  contactMethod: AuthMethod;
  arabicName: string;
}

export interface LoginInput {
  password: string;
  contactMethod: AuthMethod;
}

export type AuthError =
  | { __kind__: 'invalidEmail' }
  | { __kind__: 'invalidPhone' }
  | { __kind__: 'invalidPassword' }
  | { __kind__: 'incorrectLogin' }
  | { __kind__: 'userAlreadyExists' }
  | { __kind__: 'profileAlreadyExists' }
  | { __kind__: 'userNotFound' }
  | { __kind__: 'invalidName' }
  | { __kind__: 'missingPassword' }
  | { __kind__: 'unknown'; unknown: string };

// User Types
export interface UserProfile {
  userId: string;
  name: string;
  contactInfo: string;
  arabicName: string;
}

export type UserRole = 'admin' | 'user' | 'guest';

// Transaction Types
export type TransactionStatus = 'pending' | 'approved' | 'rejected';

export type DepositDetails = {
  amount: number;
  details: string;
};

export type WithdrawalDetails = {
  amount: number;
  destination: string;
};

export type TransferDetails = {
  amount: number;
  fromUser: Principal;
  toUser: Principal;
};

export type FeeTransactionDetails = {
  amount: number;
  feeType: string;
};

export type TransactionType =
  | { __kind__: 'deposit'; deposit: DepositDetails }
  | { __kind__: 'withdrawal'; withdrawal: WithdrawalDetails }
  | { __kind__: 'transfer'; transfer: TransferDetails }
  | { __kind__: 'fee'; fee: FeeTransactionDetails };

export interface Transaction {
  id: string;
  userId: Principal;
  amount: number;
  transactionType: TransactionType;
  status: TransactionStatus;
  timestamp: bigint;
  commissionFee: number;
}

// Wallet Types
export interface CommissionConfig {
  depositFee: number;
  withdrawalFee: number;
  transferFee: number;
}

// Manual Deposit Types
export type DepositNetwork = 'TRC20' | 'ERC20';

export type DepositMethod = 'bank' | 'usdt';

export interface ManualDepositMeta {
  userId: Principal;
  method: DepositMethod;
  network: DepositNetwork | null;
  amount: number;
  proof: string | null;
  txid: string | null;
  instructions: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: bigint;
}

// Wallet Linking Types
export type WalletLinkType =
  | { __kind__: 'trustWallet'; trustWallet: string }
  | { __kind__: 'perfectMoney'; perfectMoney: string }
  | { __kind__: 'paypal'; paypal: string };

export interface WalletLink {
  userId: Principal;
  linkType: WalletLinkType;
  timestamp: bigint;
}

// Internal Ads Types
export interface InternalAd {
  id: string;
  imageUrl: string;
  title: string;
  link: string;
  isActive: boolean;
}

export interface AdInput {
  imageUrl: string;
  title: string;
  link: string;
  isActive: boolean;
}

// API Types
export interface ApiEndpointMetaView {
  name: string;
  description: string;
  accessRole: UserRole;
}

export interface PublicSiteUrl {
  url: string;
}

// Notification Types
export type NotificationType =
  | 'depositApproved'
  | 'depositRejected'
  | 'withdrawalApproved'
  | 'withdrawalRejected'
  | 'transferReceived'
  | 'manualDepositApproved'
  | 'manualDepositRejected'
  | 'newDepositRequest'
  | 'newWithdrawalRequest'
  | 'newManualDeposit'
  | 'newUserRegistration';

export interface Notification {
  id: string;
  userId: Principal;
  notificationType: NotificationType;
  message: string;
  isRead: boolean;
  timestamp: bigint;
  relatedId: string | null;
}

// Analytics Types
export interface AnalyticsData {
  dailyRevenue: number;
  totalUsers: bigint;
  totalTransactions: bigint;
  totalCommissionEarnings: number;
  pendingDeposits: bigint;
  pendingWithdrawals: bigint;
  approvedTransactions: bigint;
  rejectedTransactions: bigint;
}

// Help Center Types
export interface FaqItem {
  id: string;
  questionAr: string;
  questionEn: string;
  answerAr: string;
  answerEn: string;
  category: string;
  order: bigint;
}

export type SupportTicketStatus = 'open' | 'inProgress' | 'closed';

export type Variant_closed_open_inProgress =
  | { __kind__: 'open' }
  | { __kind__: 'inProgress' }
  | { __kind__: 'closed' };

export interface SupportTicketResponse {
  responderId: Principal;
  message: string;
  timestamp: bigint;
  isAdmin: boolean;
}

export interface SupportTicket {
  id: string;
  userId: Principal;
  subject: string;
  message: string;
  status: Variant_closed_open_inProgress;
  timestamp: bigint;
  responses: SupportTicketResponse[];
}

export interface SupportTicketInput {
  subject: string;
  message: string;
}

export interface SupportTicketResponseInput {
  ticketId: string;
  message: string;
}
