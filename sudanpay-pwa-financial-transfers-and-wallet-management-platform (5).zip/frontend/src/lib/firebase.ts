// Mock Firebase implementation (no external dependencies required)
// This provides client-side validation and error handling for email/password authentication
// The actual authentication is handled by the backend

interface FirebaseError {
  code: string;
  message: string;
}

// Simulate Firebase email validation
const validateFirebaseEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Simulate Firebase password validation
const validateFirebasePassword = (password: string): { valid: boolean; error?: string } => {
  if (password.length < 6) {
    return { valid: false, error: 'auth/weak-password' };
  }
  return { valid: true };
};

// Mock Firebase user credential
interface MockUserCredential {
  user: {
    uid: string;
    email: string;
  };
}

// Simulate Firebase createUserWithEmailAndPassword
export const createFirebaseUser = async (email: string, password: string): Promise<MockUserCredential> => {
  // Validate email format
  if (!validateFirebaseEmail(email)) {
    const error: FirebaseError = {
      code: 'auth/invalid-email',
      message: 'The email address is badly formatted.',
    };
    throw error;
  }

  // Validate password strength
  const passwordValidation = validateFirebasePassword(password);
  if (!passwordValidation.valid) {
    const error: FirebaseError = {
      code: passwordValidation.error || 'auth/weak-password',
      message: 'Password should be at least 6 characters',
    };
    throw error;
  }

  // Simulate successful user creation
  return {
    user: {
      uid: `firebase_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      email: email,
    },
  };
};

// Initialize Firebase (mock - no-op)
export const initializeFirebase = () => {
  // Mock initialization - no actual Firebase SDK needed
  return { app: null, auth: null };
};

// Get Firebase Auth (mock - no-op)
export const getFirebaseAuth = () => {
  return null;
};

// Get localized error messages in Arabic
export const getFirebaseErrorMessage = (errorCode: string): string => {
  const errorMessages: Record<string, string> = {
    'auth/email-already-in-use': 'البريد الإلكتروني مستخدم بالفعل',
    'auth/invalid-email': 'البريد الإلكتروني غير صالح',
    'auth/operation-not-allowed': 'العملية غير مسموح بها',
    'auth/weak-password': 'كلمة المرور ضعيفة جداً. يجب أن تكون 6 أحرف على الأقل',
    'auth/network-request-failed': 'فشل الاتصال بالشبكة. يرجى التحقق من اتصالك بالإنترنت',
    'auth/too-many-requests': 'تم تجاوز عدد المحاولات. يرجى المحاولة لاحقاً',
  };

  return errorMessages[errorCode] || 'حدث خطأ أثناء إنشاء الحساب';
};
